--
-- PostgreSQL database cluster dump
--

\restrict NeV8aYVaHAd49uC7qsfUKvwxg0dBhJYbvecSbfab8EZwxso25DINwLh02CsjAf5

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE "user";
ALTER ROLE "user" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:y4qlS9PymoMeHxPtMzLoYg==$KzxqV+WYUgpoyQ3Ab3UTfVkDTFyYsgtWc61J8gh7ZKE=:OLmw6Gyqb2o/vGwu5+OCONaBTSU42Mql+0K0AW5M2nY=';

--
-- User Configurations
--








\unrestrict NeV8aYVaHAd49uC7qsfUKvwxg0dBhJYbvecSbfab8EZwxso25DINwLh02CsjAf5

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict Qnl8ylmdxKU9bFogcKEAqrFIa1IU8BtFpapNKYlVttykXSQV6CRChqIuaFLaPYF

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg13+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Qnl8ylmdxKU9bFogcKEAqrFIa1IU8BtFpapNKYlVttykXSQV6CRChqIuaFLaPYF

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict dvPp4zWfdQyVZdPTQUsqIsafnjBIPrqSbvwAyc4fecwwSoQGjiPn54lV2Te1OH5

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg13+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict dvPp4zWfdQyVZdPTQUsqIsafnjBIPrqSbvwAyc4fecwwSoQGjiPn54lV2Te1OH5

--
-- Database "resource_allocation" dump
--

--
-- PostgreSQL database dump
--

\restrict G7ZWS8T68IRG6I1egIVbWBZogSM3dA9ZI9NGJKmF3lvTq4mASMQDvO2pANEm32A

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg13+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: resource_allocation; Type: DATABASE; Schema: -; Owner: user
--

CREATE DATABASE resource_allocation WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE resource_allocation OWNER TO "user";

\unrestrict G7ZWS8T68IRG6I1egIVbWBZogSM3dA9ZI9NGJKmF3lvTq4mASMQDvO2pANEm32A
\connect resource_allocation
\restrict G7ZWS8T68IRG6I1egIVbWBZogSM3dA9ZI9NGJKmF3lvTq4mASMQDvO2pANEm32A

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dia_enum; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.dia_enum AS ENUM (
    'segunda',
    'terça',
    'quarta',
    'quinta',
    'sexta'
);


ALTER TYPE public.dia_enum OWNER TO "user";

--
-- Name: periodo; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.periodo AS ENUM (
    'manhã',
    'tarde',
    'noite'
);


ALTER TYPE public.periodo OWNER TO "user";

--
-- Name: periodo_enum; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.periodo_enum AS ENUM (
    'manhã',
    'tarde',
    'noite'
);


ALTER TYPE public.periodo_enum OWNER TO "user";

--
-- Name: role; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.role AS ENUM (
    'coordinator',
    'professor'
);


ALTER TYPE public.role OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: curso; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.curso (
    id integer NOT NULL,
    nome character varying(128) NOT NULL
);


ALTER TABLE public.curso OWNER TO "user";

--
-- Name: curso_disciplina; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.curso_disciplina (
    curso_id integer NOT NULL,
    disciplina_id integer NOT NULL,
    semestre integer NOT NULL
);


ALTER TABLE public.curso_disciplina OWNER TO "user";

--
-- Name: curso_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.curso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.curso_id_seq OWNER TO "user";

--
-- Name: curso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.curso_id_seq OWNED BY public.curso.id;


--
-- Name: disciplina; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.disciplina (
    id integer NOT NULL,
    nome character varying(128) NOT NULL,
    carga_horaria_semanal integer
);


ALTER TABLE public.disciplina OWNER TO "user";

--
-- Name: disciplina_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.disciplina_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.disciplina_id_seq OWNER TO "user";

--
-- Name: disciplina_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.disciplina_id_seq OWNED BY public.disciplina.id;


--
-- Name: disciplina_professor; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.disciplina_professor (
    disciplina_id integer NOT NULL,
    professor_id integer NOT NULL,
    prioridade integer
);


ALTER TABLE public.disciplina_professor OWNER TO "user";

--
-- Name: professor; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.professor (
    id integer NOT NULL,
    nome character varying(128) NOT NULL
);


ALTER TABLE public.professor OWNER TO "user";

--
-- Name: professor_disponibilidade; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.professor_disponibilidade (
    professor_id integer NOT NULL,
    dia public.dia_enum NOT NULL,
    periodo public.periodo NOT NULL
);


ALTER TABLE public.professor_disponibilidade OWNER TO "user";

--
-- Name: turma; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.turma (
    id integer NOT NULL,
    semestre integer NOT NULL,
    periodo public.periodo_enum
);


ALTER TABLE public.turma OWNER TO "user";

--
-- Name: turma_disciplina; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.turma_disciplina (
    turma_id integer NOT NULL,
    disciplina_id integer NOT NULL,
    professor_id integer NOT NULL,
    dia public.dia_enum NOT NULL,
    periodo public.periodo_enum NOT NULL
);


ALTER TABLE public.turma_disciplina OWNER TO "user";

--
-- Name: turma_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.turma_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.turma_id_seq OWNER TO "user";

--
-- Name: turma_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.turma_id_seq OWNED BY public.turma.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    lastname character varying(60) NOT NULL,
    email character varying(60) NOT NULL,
    password character varying(80) NOT NULL,
    role public.role NOT NULL
);


ALTER TABLE public."user" OWNER TO "user";

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO "user";

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: curso id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.curso ALTER COLUMN id SET DEFAULT nextval('public.curso_id_seq'::regclass);


--
-- Name: disciplina id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.disciplina ALTER COLUMN id SET DEFAULT nextval('public.disciplina_id_seq'::regclass);


--
-- Name: turma id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.turma ALTER COLUMN id SET DEFAULT nextval('public.turma_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: curso; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.curso (id, nome) FROM stdin;
1	Ciência da Computação (sintético)
\.


--
-- Data for Name: curso_disciplina; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.curso_disciplina (curso_id, disciplina_id, semestre) FROM stdin;
1	1	5
1	2	5
1	3	5
1	4	5
\.


--
-- Data for Name: disciplina; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.disciplina (id, nome, carga_horaria_semanal) FROM stdin;
1	Teoria dos Grafos	4
2	Processamento de Imagens	4
3	Banco de Dados	4
4	Engenharia de Software	4
\.


--
-- Data for Name: disciplina_professor; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.disciplina_professor (disciplina_id, professor_id, prioridade) FROM stdin;
1	2	1
2	2	2
3	3	1
4	3	2
\.


--
-- Data for Name: professor; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.professor (id, nome) FROM stdin;
2	Prof. A (sintético)
3	Prof. B (sintético)
\.


--
-- Data for Name: professor_disponibilidade; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.professor_disponibilidade (professor_id, dia, periodo) FROM stdin;
2	segunda	manhã
2	quarta	manhã
3	terça	noite
3	quinta	noite
\.


--
-- Data for Name: turma; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.turma (id, semestre, periodo) FROM stdin;
1	5	manhã
2	5	noite
\.


--
-- Data for Name: turma_disciplina; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.turma_disciplina (turma_id, disciplina_id, professor_id, dia, periodo) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."user" (id, name, lastname, email, password, role) FROM stdin;
1	Coordenação	(sintético)	coordenacao.dev@udf.edu.br	$2b$12$tARrAT5LlRlzcHbcSrBGVOitCXvzu6uDOW2CC2lX4AVRon4Mr5896	coordinator
2	Prof. A	(sintético)	prof.a.dev@udf.edu.br	$2b$12$1MVtvRLTx4Q2C9wvavILaeBKaFxTs2VOUJWic8BsR.GZLnmYLza7W	professor
3	Prof. B	(sintético)	prof.b.dev@udf.edu.br	$2b$12$H8HnG9WT4jS3iHgIZQcyher/WGEuXhIDz46UG137T.lWrGVKlcfQ.	professor
\.


--
-- Name: curso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.curso_id_seq', 1, true);


--
-- Name: disciplina_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.disciplina_id_seq', 4, true);


--
-- Name: turma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.turma_id_seq', 2, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.user_id_seq', 3, true);


--
-- Name: curso_disciplina curso_disciplina_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.curso_disciplina
    ADD CONSTRAINT curso_disciplina_pkey PRIMARY KEY (curso_id, disciplina_id, semestre);


--
-- Name: curso curso_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.curso
    ADD CONSTRAINT curso_pkey PRIMARY KEY (id);


--
-- Name: disciplina disciplina_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.disciplina
    ADD CONSTRAINT disciplina_pkey PRIMARY KEY (id);


--
-- Name: disciplina_professor disciplina_professor_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.disciplina_professor
    ADD CONSTRAINT disciplina_professor_pkey PRIMARY KEY (disciplina_id, professor_id);


--
-- Name: professor_disponibilidade professor_disponibilidade_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor_disponibilidade
    ADD CONSTRAINT professor_disponibilidade_pkey PRIMARY KEY (professor_id, dia, periodo);


--
-- Name: professor professor_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_pkey PRIMARY KEY (id);


--
-- Name: turma_disciplina turma_disciplina_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.turma_disciplina
    ADD CONSTRAINT turma_disciplina_pkey PRIMARY KEY (turma_id, disciplina_id, professor_id, dia, periodo);


--
-- Name: turma turma_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT turma_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: curso_disciplina curso_disciplina_curso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.curso_disciplina
    ADD CONSTRAINT curso_disciplina_curso_id_fkey FOREIGN KEY (curso_id) REFERENCES public.curso(id);


--
-- Name: curso_disciplina curso_disciplina_disciplina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.curso_disciplina
    ADD CONSTRAINT curso_disciplina_disciplina_id_fkey FOREIGN KEY (disciplina_id) REFERENCES public.disciplina(id);


--
-- Name: disciplina_professor disciplina_professor_disciplina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.disciplina_professor
    ADD CONSTRAINT disciplina_professor_disciplina_id_fkey FOREIGN KEY (disciplina_id) REFERENCES public.disciplina(id);


--
-- Name: disciplina_professor disciplina_professor_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.disciplina_professor
    ADD CONSTRAINT disciplina_professor_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.professor(id);


--
-- Name: professor_disponibilidade professor_disponibilidade_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor_disponibilidade
    ADD CONSTRAINT professor_disponibilidade_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.professor(id);


--
-- Name: professor professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_id_fkey FOREIGN KEY (id) REFERENCES public."user"(id);


--
-- Name: turma_disciplina turma_disciplina_disciplina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.turma_disciplina
    ADD CONSTRAINT turma_disciplina_disciplina_id_fkey FOREIGN KEY (disciplina_id) REFERENCES public.disciplina(id);


--
-- Name: turma_disciplina turma_disciplina_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.turma_disciplina
    ADD CONSTRAINT turma_disciplina_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.professor(id);


--
-- Name: turma_disciplina turma_disciplina_turma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.turma_disciplina
    ADD CONSTRAINT turma_disciplina_turma_id_fkey FOREIGN KEY (turma_id) REFERENCES public.turma(id);


--
-- PostgreSQL database dump complete
--

\unrestrict G7ZWS8T68IRG6I1egIVbWBZogSM3dA9ZI9NGJKmF3lvTq4mASMQDvO2pANEm32A

--
-- PostgreSQL database cluster dump complete
--

