--
-- PostgreSQL database cluster dump
--

\restrict 6shKfJplfNABtAwjXeLOgMcGis5PIU5fYyFdBFqNEFtCNKqRLK1nNcuY0hXK9yH

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE events;
ALTER ROLE events WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:nxdgkPqDs0zTZLo+fRdjWA==$fc+vmGmSVsgoXByr4uY5tbL166LAYlzU9fmGgNX+O/c=:aTYWCg74e167lSSuSBWTHBvinAEphyoXomrfJ51Z7QU=';






\unrestrict 6shKfJplfNABtAwjXeLOgMcGis5PIU5fYyFdBFqNEFtCNKqRLK1nNcuY0hXK9yH

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict I7HokhjCjAMmdmIsUkK8mst4S4kfuTwSf5HWyC9CePf8AE4ujd0bw0WCEARnh0q

-- Dumped from database version 14.24 (Debian 14.24-1.pgdg13+2)
-- Dumped by pg_dump version 14.24 (Debian 14.24-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict I7HokhjCjAMmdmIsUkK8mst4S4kfuTwSf5HWyC9CePf8AE4ujd0bw0WCEARnh0q

--
-- Database "events_db" dump
--

--
-- PostgreSQL database dump
--

\restrict Xc5FYJ33TofJGFLFfshzXjY5HUXtSfaXuGTMVd9KKlzVB02144dNWUtgsqcpMll

-- Dumped from database version 14.24 (Debian 14.24-1.pgdg13+2)
-- Dumped by pg_dump version 14.24 (Debian 14.24-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: events_db; Type: DATABASE; Schema: -; Owner: events
--

CREATE DATABASE events_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE events_db OWNER TO events;

\unrestrict Xc5FYJ33TofJGFLFfshzXjY5HUXtSfaXuGTMVd9KKlzVB02144dNWUtgsqcpMll
\connect events_db
\restrict Xc5FYJ33TofJGFLFfshzXjY5HUXtSfaXuGTMVd9KKlzVB02144dNWUtgsqcpMll

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: eventos; Type: SCHEMA; Schema: -; Owner: events
--

CREATE SCHEMA eventos;


ALTER SCHEMA eventos OWNER TO events;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: arquivo_tb; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.arquivo_tb (
    id bigint NOT NULL,
    created_date timestamp(6) without time zone NOT NULL,
    created_by character varying(255) NOT NULL,
    excluded boolean,
    updated_date timestamp(6) without time zone NOT NULL,
    updated_by character varying(255) NOT NULL,
    uid uuid DEFAULT gen_random_uuid(),
    key character varying(255),
    name character varying(255),
    size bigint,
    type character varying(255),
    url character varying(255)
);


ALTER TABLE eventos.arquivo_tb OWNER TO events;

--
-- Name: arquivo_tb_id_seq; Type: SEQUENCE; Schema: eventos; Owner: events
--

CREATE SEQUENCE eventos.arquivo_tb_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE -9223372036854775808
    NO MAXVALUE
    CACHE 1
    CYCLE;


ALTER TABLE eventos.arquivo_tb_id_seq OWNER TO events;

--
-- Name: arquivo_tb_id_seq; Type: SEQUENCE OWNED BY; Schema: eventos; Owner: events
--

ALTER SEQUENCE eventos.arquivo_tb_id_seq OWNED BY eventos.arquivo_tb.id;


--
-- Name: evento_ods_tb; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.evento_ods_tb (
    evento_id bigint NOT NULL,
    ods_id bigint NOT NULL
);


ALTER TABLE eventos.evento_ods_tb OWNER TO events;

--
-- Name: evento_tb; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.evento_tb (
    id bigint NOT NULL,
    created_date timestamp(6) without time zone NOT NULL,
    created_by character varying(255) NOT NULL,
    excluded boolean,
    updated_date timestamp(6) without time zone NOT NULL,
    updated_by character varying(255) NOT NULL,
    address character varying(255),
    cor character varying(255),
    date_hora character varying(255),
    description text,
    name character varying(255),
    name_card character varying(255),
    status character varying(255),
    photo_id bigint,
    CONSTRAINT evento_tb_status_check CHECK (((status)::text = ANY ((ARRAY['C'::character varying, 'AV'::character varying, 'R'::character varying, 'IN'::character varying, 'F'::character varying, 'AP'::character varying])::text[])))
);


ALTER TABLE eventos.evento_tb OWNER TO events;

--
-- Name: evento_tb_id_seq; Type: SEQUENCE; Schema: eventos; Owner: events
--

CREATE SEQUENCE eventos.evento_tb_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE -9223372036854775808
    NO MAXVALUE
    CACHE 1
    CYCLE;


ALTER TABLE eventos.evento_tb_id_seq OWNER TO events;

--
-- Name: evento_tb_id_seq; Type: SEQUENCE OWNED BY; Schema: eventos; Owner: events
--

ALTER SEQUENCE eventos.evento_tb_id_seq OWNED BY eventos.evento_tb.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE eventos.flyway_schema_history OWNER TO events;

--
-- Name: long; Type: SEQUENCE; Schema: eventos; Owner: events
--

CREATE SEQUENCE eventos.long
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE eventos.long OWNER TO events;

--
-- Name: ods_tb; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.ods_tb (
    id bigint NOT NULL,
    created_date timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by character varying(255) NOT NULL,
    excluded boolean,
    updated_date timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by character varying(255) NOT NULL,
    description character varying(255),
    name character varying(255),
    status boolean NOT NULL
);


ALTER TABLE eventos.ods_tb OWNER TO events;

--
-- Name: ods_tb_id_seq; Type: SEQUENCE; Schema: eventos; Owner: events
--

CREATE SEQUENCE eventos.ods_tb_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE -9223372036854775808
    NO MAXVALUE
    CACHE 1
    CYCLE;


ALTER TABLE eventos.ods_tb_id_seq OWNER TO events;

--
-- Name: ods_tb_id_seq; Type: SEQUENCE OWNED BY; Schema: eventos; Owner: events
--

ALTER SEQUENCE eventos.ods_tb_id_seq OWNED BY eventos.ods_tb.id;


--
-- Name: user_permissions; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.user_permissions (
    user_id bigint NOT NULL,
    roles character varying(255) NOT NULL
);


ALTER TABLE eventos.user_permissions OWNER TO events;

--
-- Name: users_tb; Type: TABLE; Schema: eventos; Owner: events
--

CREATE TABLE eventos.users_tb (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    foto_perfil_id bigint,
    foto_capa_id bigint,
    excluded boolean DEFAULT false,
    created_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255),
    updated_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by character varying(255)
);


ALTER TABLE eventos.users_tb OWNER TO events;

--
-- Name: users_tb_id_seq; Type: SEQUENCE; Schema: eventos; Owner: events
--

CREATE SEQUENCE eventos.users_tb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE eventos.users_tb_id_seq OWNER TO events;

--
-- Name: users_tb_id_seq; Type: SEQUENCE OWNED BY; Schema: eventos; Owner: events
--

ALTER SEQUENCE eventos.users_tb_id_seq OWNED BY eventos.users_tb.id;


--
-- Name: arquivo_tb id; Type: DEFAULT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.arquivo_tb ALTER COLUMN id SET DEFAULT nextval('eventos.arquivo_tb_id_seq'::regclass);


--
-- Name: evento_tb id; Type: DEFAULT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.evento_tb ALTER COLUMN id SET DEFAULT nextval('eventos.evento_tb_id_seq'::regclass);


--
-- Name: ods_tb id; Type: DEFAULT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.ods_tb ALTER COLUMN id SET DEFAULT nextval('eventos.ods_tb_id_seq'::regclass);


--
-- Name: users_tb id; Type: DEFAULT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.users_tb ALTER COLUMN id SET DEFAULT nextval('eventos.users_tb_id_seq'::regclass);


--
-- Data for Name: arquivo_tb; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.arquivo_tb (id, created_date, created_by, excluded, updated_date, updated_by, uid, key, name, size, type, url) FROM stdin;
1	2026-09-24 18:11:52.832215	admin	f	2026-09-24 18:11:52.832313	admin	\N	\N	\N	\N	\N	\N
2	2026-09-24 18:11:52.886971	admin	f	2026-09-24 18:11:52.887015	admin	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: evento_ods_tb; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.evento_ods_tb (evento_id, ods_id) FROM stdin;
\.


--
-- Data for Name: evento_tb; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.evento_tb (id, created_date, created_by, excluded, updated_date, updated_by, address, cor, date_hora, description, name, name_card, status, photo_id) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
0	\N	<< Flyway Schema Creation >>	SCHEMA	"eventos"	\N	events	2026-09-24 18:11:19.083254	0	t
1	002	create table arquivo	SQL	V002__create_table_arquivo.sql	2065248641	events	2026-09-24 18:11:19.094204	18	t
2	003	create table ods	SQL	V003__create_table_ods.sql	-1080450829	events	2026-09-24 18:11:19.13216	9	t
3	004	create table evento	SQL	V004__create_table_evento.sql	912034373	events	2026-09-24 18:11:19.162413	9	t
4	005	create table evento ods	SQL	V005__create_table_evento_ods.sql	312441009	events	2026-09-24 18:11:19.183758	4	t
5	006	create table users	SQL	V006__create_table_users.sql	752524036	events	2026-09-24 18:11:19.19368	8	t
\.


--
-- Data for Name: ods_tb; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.ods_tb (id, created_date, created_by, excluded, updated_date, updated_by, description, name, status) FROM stdin;
1	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Acabar com a pobreza em todas as suas formas, em todos os lugares	Erradicação da Pobreza	t
2	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Acabar com a fome, alcançar a segurança alimentar e nutrição melhorada e promover a agricultura sustentável	Fome Zero e Agricultura Sustentável	t
3	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Assegurar uma vida saudável e promover o bem-estar para todos, em todas as idades	Saúde de Qualidade	t
4	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Assegurar a educação inclusiva e de qualidade para todos e promover oportunidades de aprendizagem ao longo da vida	Educação de Qualidade	t
5	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Alcançar a igualdade de gênero e empoderar todas as mulheres e meninas	Igualdade de Gênero	t
6	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Assegurar a disponibilidade e gestão sustentável da água e do saneamento para todos	Água Potável e Saneamento	t
7	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Assegurar o acesso à energia acessível, confiável, sustentável e moderna para todos	Energia Acessível e Limpa	t
8	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Promover o crescimento econômico inclusivo e sustentável, o emprego pleno e produtivo e o trabalho decente para todos	Trabalho Decente e Crescimento Econômico	t
9	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Construir uma infraestrutura resiliente, promover a industrialização inclusiva e sustentável e fomentar a inovação	Indústria, Inovação e Infraestrutura	t
10	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Reduzir a desigualdade dentro dos países e entre eles	Redução das Desigualdades	t
11	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Tornar as cidades e os assentamentos humanos inclusivos, seguros, resilientes e sustentáveis	Cidades e Comunidades Sustentáveis	t
12	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Assegurar padrões de produção e consumo sustentáveis	Produção e Consumo Responsáveis	t
13	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Tomar medidas urgentes para combater a mudança climática e seus impactos	Ação contra a Mudança Global do Clima	t
14	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Conservar e usar de forma sustentável os oceanos, mares e recursos marinhos para o desenvolvimento sustentável	Vida na Água	t
15	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Proteger, restaurar e promover o uso sustentável dos ecossistemas terrestres, gerir de forma sustentável as florestas, combater a desertificação e deter e reverter a degradação da terra e a perda de biodiversidade	Vida Terrestre	t
16	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Promover sociedades pacíficas e inclusivas para o desenvolvimento sustentável, proporcionar o acesso à justiça para todos e construir instituições eficazes, responsáveis e inclusivas em todos os níveis	Paz, Justiça e Instituições Fortes	t
17	2026-09-24 18:11:19.14745	admin	f	2026-09-24 18:11:19.14745	admin	Revigorar a parceria global para o desenvolvimento sustentável e fortalecer os meios de implementação e revitalizar a Parceria Global para o Desenvolvimento Sustentável	Parcerias para as Metas	t
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.user_permissions (user_id, roles) FROM stdin;
1	USER
1	ADMIN
\.


--
-- Data for Name: users_tb; Type: TABLE DATA; Schema: eventos; Owner: events
--

COPY eventos.users_tb (id, uid, name, email, password, foto_perfil_id, foto_capa_id, excluded, created_date, created_by, updated_date, updated_by) FROM stdin;
1	990fd2d4-48c5-41ae-a5ad-b3141aa80c4f	Dev Sintético	dev.eventos@udf.edu.br	$2a$10$OEUPbDluX0eZBf3lmbswxuEukLglLLbo6yp7S8Mzz8/dH4XCWB8Hq	2	1	f	2026-09-24 18:11:52.88961	admin	2026-09-24 18:11:53.203039	admin
\.


--
-- Name: arquivo_tb_id_seq; Type: SEQUENCE SET; Schema: eventos; Owner: events
--

SELECT pg_catalog.setval('eventos.arquivo_tb_id_seq', 2, true);


--
-- Name: evento_tb_id_seq; Type: SEQUENCE SET; Schema: eventos; Owner: events
--

SELECT pg_catalog.setval('eventos.evento_tb_id_seq', 1, false);


--
-- Name: long; Type: SEQUENCE SET; Schema: eventos; Owner: events
--

SELECT pg_catalog.setval('eventos.long', 1, false);


--
-- Name: ods_tb_id_seq; Type: SEQUENCE SET; Schema: eventos; Owner: events
--

SELECT pg_catalog.setval('eventos.ods_tb_id_seq', 1, false);


--
-- Name: users_tb_id_seq; Type: SEQUENCE SET; Schema: eventos; Owner: events
--

SELECT pg_catalog.setval('eventos.users_tb_id_seq', 1, true);


--
-- Name: arquivo_tb arquivo_tb_pkey; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.arquivo_tb
    ADD CONSTRAINT arquivo_tb_pkey PRIMARY KEY (id);


--
-- Name: evento_ods_tb evento_ods_tb_pkey; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.evento_ods_tb
    ADD CONSTRAINT evento_ods_tb_pkey PRIMARY KEY (evento_id, ods_id);


--
-- Name: evento_tb evento_tb_pkey; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.evento_tb
    ADD CONSTRAINT evento_tb_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: ods_tb ods_tb_pkey; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.ods_tb
    ADD CONSTRAINT ods_tb_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pk; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.user_permissions
    ADD CONSTRAINT user_permissions_pk PRIMARY KEY (user_id, roles);


--
-- Name: users_tb users_tb_pkey; Type: CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.users_tb
    ADD CONSTRAINT users_tb_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: eventos; Owner: events
--

CREATE INDEX flyway_schema_history_s_idx ON eventos.flyway_schema_history USING btree (success);


--
-- Name: evento_ods_tb evento_ods_tb_evento_id_fkey; Type: FK CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.evento_ods_tb
    ADD CONSTRAINT evento_ods_tb_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES eventos.evento_tb(id);


--
-- Name: evento_ods_tb evento_ods_tb_ods_id_fkey; Type: FK CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.evento_ods_tb
    ADD CONSTRAINT evento_ods_tb_ods_id_fkey FOREIGN KEY (ods_id) REFERENCES eventos.ods_tb(id);


--
-- Name: evento_tb fk157hrp81o2g049knufbyat8kw; Type: FK CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.evento_tb
    ADD CONSTRAINT fk157hrp81o2g049knufbyat8kw FOREIGN KEY (photo_id) REFERENCES eventos.arquivo_tb(id);


--
-- Name: users_tb fk_foto_capa; Type: FK CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.users_tb
    ADD CONSTRAINT fk_foto_capa FOREIGN KEY (foto_capa_id) REFERENCES eventos.arquivo_tb(id);


--
-- Name: users_tb fk_foto_perfil; Type: FK CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.users_tb
    ADD CONSTRAINT fk_foto_perfil FOREIGN KEY (foto_perfil_id) REFERENCES eventos.arquivo_tb(id);


--
-- Name: user_permissions fk_user_id; Type: FK CONSTRAINT; Schema: eventos; Owner: events
--

ALTER TABLE ONLY eventos.user_permissions
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES eventos.users_tb(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Xc5FYJ33TofJGFLFfshzXjY5HUXtSfaXuGTMVd9KKlzVB02144dNWUtgsqcpMll

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 6VhBDx5b0UKHaVqZvObNmVJu0yXhxZFcD5MLDf8OtlFemzVYMbpMCfNPP4oQI5e

-- Dumped from database version 14.24 (Debian 14.24-1.pgdg13+2)
-- Dumped by pg_dump version 14.24 (Debian 14.24-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 6VhBDx5b0UKHaVqZvObNmVJu0yXhxZFcD5MLDf8OtlFemzVYMbpMCfNPP4oQI5e

--
-- PostgreSQL database cluster dump complete
--

