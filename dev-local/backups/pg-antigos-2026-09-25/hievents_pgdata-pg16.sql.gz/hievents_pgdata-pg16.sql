--
-- PostgreSQL database cluster dump
--

\restrict 8jV2eQ3PwqsrL0zcc6OZXphjTdJVyJZGfmyKpprTnzDSv1pOtP7LXf1uENOEUDU

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:ohmjpV5p4xDzTmUGaqwOuA==$ML4Q3+UT6IjMlNHIdw6orbuD05jJEnlwDYLY0NQFe+8=:61ShAn2GV4C5LyF0IWVI1lHNsyYzSVAf6h89lJCzQzU=';

--
-- User Configurations
--








\unrestrict 8jV2eQ3PwqsrL0zcc6OZXphjTdJVyJZGfmyKpprTnzDSv1pOtP7LXf1uENOEUDU

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict ctUj7Te4dd6vty1KaDNVx1hFOtfByzrW5tfPDlxYp2MVWLTYZwfyf6m6yKLie9r

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ctUj7Te4dd6vty1KaDNVx1hFOtfByzrW5tfPDlxYp2MVWLTYZwfyf6m6yKLie9r

--
-- Database "hi-events" dump
--

--
-- PostgreSQL database dump
--

\restrict fUBnUJj7LfD5R0RB6YvkV8J2bUc3Wrey1RB6CQ5Ee8ivBN7aWeHCax0Tn9PXfvE

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hi-events; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "hi-events" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "hi-events" OWNER TO postgres;

\unrestrict fUBnUJj7LfD5R0RB6YvkV8J2bUc3Wrey1RB6CQ5Ee8ivBN7aWeHCax0Tn9PXfvE
\encoding SQL_ASCII
\connect -reuse-previous=on "dbname='hi-events'"
\restrict fUBnUJj7LfD5R0RB6YvkV8J2bUc3Wrey1RB6CQ5Ee8ivBN7aWeHCax0Tn9PXfvE

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_attributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_attributions (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    utm_source character varying(255),
    utm_medium character varying(255),
    utm_campaign character varying(255),
    utm_term character varying(255),
    utm_content character varying(255),
    referrer_url text,
    landing_page text,
    gclid character varying(255),
    fbclid character varying(255),
    source_type character varying(20),
    utm_raw jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.account_attributions OWNER TO postgres;

--
-- Name: account_attributions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_attributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_attributions_id_seq OWNER TO postgres;

--
-- Name: account_attributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_attributions_id_seq OWNED BY public.account_attributions.id;


--
-- Name: account_configuration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_configuration (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    is_system_default boolean DEFAULT false NOT NULL,
    application_fees json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    bypass_application_fees boolean DEFAULT false NOT NULL
);


ALTER TABLE public.account_configuration OWNER TO postgres;

--
-- Name: account_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_configuration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_configuration_id_seq OWNER TO postgres;

--
-- Name: account_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_configuration_id_seq OWNED BY public.account_configuration.id;


--
-- Name: account_deletion_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_deletion_requests (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    requested_by_user_id bigint NOT NULL,
    initiated_by character varying(40) NOT NULL,
    reason text,
    status character varying(40) DEFAULT 'REQUESTED'::character varying NOT NULL,
    expected_outcome character varying(40),
    outcome character varying(40),
    scheduled_deletion_at timestamp(0) without time zone NOT NULL,
    reminder_sent_at timestamp(0) without time zone,
    cancelled_at timestamp(0) without time zone,
    cancelled_by_user_id bigint,
    completed_at timestamp(0) without time zone,
    deletion_manifest jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.account_deletion_requests OWNER TO postgres;

--
-- Name: account_deletion_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_deletion_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_deletion_requests_id_seq OWNER TO postgres;

--
-- Name: account_deletion_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_deletion_requests_id_seq OWNED BY public.account_deletion_requests.id;


--
-- Name: account_messaging_tiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_messaging_tiers (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    max_messages_per_24h integer NOT NULL,
    max_recipients_per_message integer NOT NULL,
    links_allowed boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.account_messaging_tiers OWNER TO postgres;

--
-- Name: account_messaging_tiers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_messaging_tiers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_messaging_tiers_id_seq OWNER TO postgres;

--
-- Name: account_messaging_tiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_messaging_tiers_id_seq OWNED BY public.account_messaging_tiers.id;


--
-- Name: account_stripe_platforms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_stripe_platforms (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    stripe_connect_account_type character varying(255),
    stripe_connect_platform character varying(2),
    stripe_account_id character varying(255),
    stripe_setup_completed_at timestamp(0) without time zone,
    stripe_account_details jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.account_stripe_platforms OWNER TO postgres;

--
-- Name: account_stripe_platforms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_stripe_platforms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_stripe_platforms_id_seq OWNER TO postgres;

--
-- Name: account_stripe_platforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_stripe_platforms_id_seq OWNED BY public.account_stripe_platforms.id;


--
-- Name: account_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_users (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_account_owner boolean DEFAULT false NOT NULL,
    invited_by_user_id bigint,
    last_login_at timestamp without time zone,
    status character varying(40) DEFAULT 'INVITED'::character varying NOT NULL
);


ALTER TABLE public.account_users OWNER TO postgres;

--
-- Name: account_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.account_users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.account_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: account_vat_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_vat_settings (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    vat_registered boolean DEFAULT false NOT NULL,
    vat_number character varying(20),
    vat_validated boolean DEFAULT false NOT NULL,
    vat_validation_date timestamp(0) without time zone,
    business_name character varying(255),
    business_address character varying(255),
    vat_country_code character varying(2),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    vat_validation_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    vat_validation_error text,
    vat_validation_attempts integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.account_vat_settings OWNER TO postgres;

--
-- Name: account_vat_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_vat_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_vat_settings_id_seq OWNER TO postgres;

--
-- Name: account_vat_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_vat_settings_id_seq OWNED BY public.account_vat_settings.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id bigint NOT NULL,
    currency_code character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    name character varying NOT NULL,
    email character varying NOT NULL,
    stripe_account_id character varying(50),
    short_id character varying(20) NOT NULL,
    stripe_connect_setup_complete boolean DEFAULT false,
    account_verified_at timestamp without time zone,
    stripe_connect_account_type character varying(255),
    account_configuration_id bigint,
    is_manually_verified boolean DEFAULT false NOT NULL,
    country character varying(2),
    account_messaging_tier_id bigint
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.accounts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: affiliates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.affiliates (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    account_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    email character varying(255),
    total_sales integer DEFAULT 0 NOT NULL,
    total_sales_gross double precision DEFAULT '0'::double precision NOT NULL,
    status character varying(255) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT affiliates_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying])::text[])))
);


ALTER TABLE public.affiliates OWNER TO postgres;

--
-- Name: affiliates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.affiliates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.affiliates_id_seq OWNER TO postgres;

--
-- Name: affiliates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.affiliates_id_seq OWNED BY public.affiliates.id;


--
-- Name: announcement_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcement_users (
    id bigint NOT NULL,
    announcement_id bigint NOT NULL,
    user_id bigint NOT NULL,
    first_seen_at timestamp(0) without time zone NOT NULL,
    dismissed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.announcement_users OWNER TO postgres;

--
-- Name: announcement_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcement_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.announcement_users_id_seq OWNER TO postgres;

--
-- Name: announcement_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcement_users_id_seq OWNED BY public.announcement_users.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    status character varying(255) DEFAULT 'DRAFT'::character varying NOT NULL,
    display_type character varying(255) NOT NULL,
    emoji character varying(255),
    target_type character varying(255) DEFAULT 'ALL'::character varying NOT NULL,
    target_account_ids json,
    target_user_ids json,
    cta_label character varying(255),
    cta_url character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.announcements_id_seq OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: attendee_check_ins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendee_check_ins (
    id bigint NOT NULL,
    short_id character varying(255) NOT NULL,
    check_in_list_id bigint NOT NULL,
    product_id bigint NOT NULL,
    attendee_id bigint NOT NULL,
    ip_address inet NOT NULL,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    event_id bigint NOT NULL,
    order_id bigint,
    event_occurrence_id bigint
);


ALTER TABLE public.attendee_check_ins OWNER TO postgres;

--
-- Name: attendee_check_ins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendee_check_ins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendee_check_ins_id_seq OWNER TO postgres;

--
-- Name: attendee_check_ins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendee_check_ins_id_seq OWNED BY public.attendee_check_ins.id;


--
-- Name: attendees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendees (
    id bigint NOT NULL,
    short_id character varying NOT NULL,
    first_name character varying(255) DEFAULT ''::character varying NOT NULL,
    last_name character varying(255) DEFAULT ''::character varying NOT NULL,
    email character varying(255) NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    event_id integer NOT NULL,
    public_id character varying NOT NULL,
    status character varying(20) NOT NULL,
    checked_in_by bigint,
    checked_in_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    checked_out_by bigint,
    product_price_id bigint NOT NULL,
    locale character varying(20) DEFAULT 'en'::character varying NOT NULL,
    notes text,
    event_occurrence_id bigint
);


ALTER TABLE public.attendees OWNER TO postgres;

--
-- Name: attendees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.attendees ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.attendees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: capacity_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.capacity_assignments (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    capacity integer,
    used_capacity integer DEFAULT 0 NOT NULL,
    applies_to character varying(255) DEFAULT 'EVENT'::character varying NOT NULL,
    status character varying(255) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.capacity_assignments OWNER TO postgres;

--
-- Name: capacity_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.capacity_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.capacity_assignments_id_seq OWNER TO postgres;

--
-- Name: capacity_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.capacity_assignments_id_seq OWNED BY public.capacity_assignments.id;


--
-- Name: check_in_lists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.check_in_lists (
    id bigint NOT NULL,
    short_id character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    expires_at timestamp(0) without time zone,
    activates_at timestamp(0) without time zone,
    event_id bigint NOT NULL,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    event_occurrence_id bigint,
    public_show_attendee_notes boolean DEFAULT false NOT NULL,
    public_show_question_answers boolean DEFAULT false NOT NULL,
    public_show_order_details boolean DEFAULT false NOT NULL,
    is_system_default boolean DEFAULT false NOT NULL
);


ALTER TABLE public.check_in_lists OWNER TO postgres;

--
-- Name: check_in_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.check_in_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.check_in_lists_id_seq OWNER TO postgres;

--
-- Name: check_in_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.check_in_lists_id_seq OWNED BY public.check_in_lists.id;


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_templates (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    organizer_id bigint,
    event_id bigint,
    template_type character varying(50) NOT NULL,
    subject character varying(255) NOT NULL,
    body text NOT NULL,
    cta json,
    engine character varying(20) DEFAULT 'liquid'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.email_templates OWNER TO postgres;

--
-- Name: email_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_templates_id_seq OWNER TO postgres;

--
-- Name: email_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_templates_id_seq OWNED BY public.email_templates.id;


--
-- Name: event_daily_statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_daily_statistics (
    id bigint NOT NULL,
    sales_total_gross numeric(14,2) DEFAULT 0.00 NOT NULL,
    total_tax numeric(14,2) DEFAULT 0.00 NOT NULL,
    sales_total_before_additions numeric(14,2) DEFAULT 0.00 NOT NULL,
    products_sold integer DEFAULT 0 NOT NULL,
    orders_created integer DEFAULT 0 NOT NULL,
    date date NOT NULL,
    created_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    total_fee numeric(14,2) DEFAULT 0 NOT NULL,
    event_id bigint NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    total_refunded numeric(14,2) DEFAULT 0 NOT NULL,
    total_views bigint DEFAULT 0 NOT NULL,
    attendees_registered integer DEFAULT 0 NOT NULL,
    orders_cancelled integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.event_daily_statistics OWNER TO postgres;

--
-- Name: event_daily_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.event_daily_statistics ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.event_daily_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: event_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_locations (
    id bigint NOT NULL,
    short_id character varying(20) NOT NULL,
    event_id bigint NOT NULL,
    type character varying(20) DEFAULT 'IN_PERSON'::character varying NOT NULL,
    location_id bigint,
    online_event_connection_details text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.event_locations OWNER TO postgres;

--
-- Name: event_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_locations_id_seq OWNER TO postgres;

--
-- Name: event_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_locations_id_seq OWNED BY public.event_locations.id;


--
-- Name: event_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_logs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(255) NOT NULL,
    entity_id bigint NOT NULL,
    entity_type bigint NOT NULL,
    ip_address character varying,
    user_agent character varying,
    data jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.event_logs OWNER TO postgres;

--
-- Name: event_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.event_logs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.event_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: event_occurrence_daily_statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_occurrence_daily_statistics (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    event_occurrence_id bigint NOT NULL,
    date date NOT NULL,
    products_sold integer DEFAULT 0 NOT NULL,
    attendees_registered integer DEFAULT 0 NOT NULL,
    sales_total_gross numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    sales_total_before_additions numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_tax numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_fee numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    orders_created integer DEFAULT 0 NOT NULL,
    orders_cancelled integer DEFAULT 0 NOT NULL,
    total_refunded numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.event_occurrence_daily_statistics OWNER TO postgres;

--
-- Name: event_occurrence_daily_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_occurrence_daily_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_occurrence_daily_statistics_id_seq OWNER TO postgres;

--
-- Name: event_occurrence_daily_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_occurrence_daily_statistics_id_seq OWNED BY public.event_occurrence_daily_statistics.id;


--
-- Name: event_occurrence_statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_occurrence_statistics (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    event_occurrence_id bigint NOT NULL,
    products_sold integer DEFAULT 0 NOT NULL,
    attendees_registered integer DEFAULT 0 NOT NULL,
    sales_total_gross numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    sales_total_before_additions numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_tax numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_fee numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    orders_created integer DEFAULT 0 NOT NULL,
    orders_cancelled integer DEFAULT 0 NOT NULL,
    total_refunded numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.event_occurrence_statistics OWNER TO postgres;

--
-- Name: event_occurrence_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_occurrence_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_occurrence_statistics_id_seq OWNER TO postgres;

--
-- Name: event_occurrence_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_occurrence_statistics_id_seq OWNED BY public.event_occurrence_statistics.id;


--
-- Name: event_occurrences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_occurrences (
    id bigint NOT NULL,
    short_id character varying(255) NOT NULL,
    event_id bigint NOT NULL,
    start_date timestamp(0) without time zone NOT NULL,
    end_date timestamp(0) without time zone,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    capacity integer,
    used_capacity integer DEFAULT 0 NOT NULL,
    label character varying(255),
    is_overridden boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    event_location_id bigint,
    show_available_capacity boolean,
    cancelled_attendees_count integer
);


ALTER TABLE public.event_occurrences OWNER TO postgres;

--
-- Name: event_occurrences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_occurrences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_occurrences_id_seq OWNER TO postgres;

--
-- Name: event_occurrences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_occurrences_id_seq OWNED BY public.event_occurrences.id;


--
-- Name: event_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_settings (
    id bigint NOT NULL,
    pre_checkout_message text,
    post_checkout_message text,
    product_page_message text,
    continue_button_text character varying(100),
    email_footer_message text,
    support_email character varying(255),
    event_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    require_attendee_details boolean DEFAULT true NOT NULL,
    order_timeout_in_minutes integer DEFAULT 15 NOT NULL,
    website_url character varying(400),
    maps_url character varying(2000),
    homepage_background_color character varying(20),
    homepage_primary_text_color character varying(20),
    homepage_primary_color character varying(20),
    homepage_secondary_text_color character varying(20),
    homepage_secondary_color character varying(20),
    location_details jsonb,
    online_event_connection_details text,
    is_online_event boolean DEFAULT false NOT NULL,
    allow_search_engine_indexing boolean DEFAULT true NOT NULL,
    seo_title character varying(255),
    seo_description character varying(255),
    social_media_handles jsonb,
    show_social_media_handles boolean,
    seo_keywords character varying(255),
    notify_organizer_of_new_orders boolean DEFAULT true NOT NULL,
    price_display_mode character varying(255) DEFAULT 'INCLUSIVE'::character varying NOT NULL,
    show_share_buttons boolean DEFAULT true NOT NULL,
    homepage_body_background_color character varying(100),
    homepage_background_type character varying(30) DEFAULT 'COLOR'::character varying NOT NULL,
    enable_invoicing boolean DEFAULT false NOT NULL,
    invoice_label character varying(255),
    invoice_prefix character varying(255),
    invoice_start_number integer DEFAULT 1 NOT NULL,
    require_billing_address boolean DEFAULT true NOT NULL,
    organization_name character varying(255),
    organization_address text,
    invoice_tax_details text,
    payment_providers json,
    offline_payment_instructions text,
    allow_orders_awaiting_offline_payment_to_check_in boolean DEFAULT false NOT NULL,
    invoice_payment_terms_days integer,
    invoice_notes text,
    ticket_design_settings jsonb,
    attendee_details_collection_method character varying(255) DEFAULT 'PER_TICKET'::character varying NOT NULL,
    show_marketing_opt_in boolean DEFAULT true NOT NULL,
    homepage_theme_settings jsonb,
    pass_platform_fee_to_buyer boolean DEFAULT false NOT NULL,
    allow_attendee_self_edit boolean DEFAULT true NOT NULL,
    waitlist_enabled boolean DEFAULT false NOT NULL,
    waitlist_auto_process boolean DEFAULT false NOT NULL,
    waitlist_offer_timeout_minutes integer,
    allow_copy_details_to_all_attendees boolean DEFAULT true NOT NULL,
    show_available_occurrence_capacity boolean DEFAULT false NOT NULL,
    hide_sold_out_occurrences boolean DEFAULT false NOT NULL,
    get_tickets_button_text character varying(100),
    CONSTRAINT event_settings_price_display_mode_check CHECK (((price_display_mode)::text = ANY (ARRAY[('INCLUSIVE'::character varying)::text, ('EXCLUSIVE'::character varying)::text])))
);


ALTER TABLE public.event_settings OWNER TO postgres;

--
-- Name: event_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.event_settings ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.event_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: event_statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_statistics (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    unique_views bigint DEFAULT 0 NOT NULL,
    total_views bigint DEFAULT 0 NOT NULL,
    sales_total_gross numeric(14,2) DEFAULT 0.00 NOT NULL,
    total_tax numeric(14,2) DEFAULT 0.00 NOT NULL,
    sales_total_before_additions numeric(14,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    total_fee numeric(14,2) DEFAULT 0.00 NOT NULL,
    products_sold integer DEFAULT 0 NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    orders_created integer DEFAULT 0 NOT NULL,
    total_refunded numeric(14,2) DEFAULT 0 NOT NULL,
    attendees_registered integer DEFAULT 0 NOT NULL,
    orders_cancelled integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.event_statistics OWNER TO postgres;

--
-- Name: event_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.event_statistics ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.event_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    account_id integer NOT NULL,
    user_id integer NOT NULL,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    description text,
    status character varying,
    location_details jsonb,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying,
    attributes jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    location character varying(255),
    organizer_id bigint,
    short_id character varying(32) NOT NULL,
    ticket_quantity_available integer,
    category character varying(255) DEFAULT 'OTHER'::character varying NOT NULL,
    type character varying(20) DEFAULT 'SINGLE'::character varying NOT NULL,
    recurrence_rule jsonb,
    event_location_id bigint,
    CONSTRAINT events_category_check CHECK (((category)::text = ANY ((ARRAY['SOCIAL'::character varying, 'FAMILY'::character varying, 'HOBBIES'::character varying, 'FOOD_DRINK'::character varying, 'WELLNESS'::character varying, 'SPIRITUALITY'::character varying, 'OUTDOORS'::character varying, 'TOURS'::character varying, 'CHARITY'::character varying, 'MUSIC'::character varying, 'ART'::character varying, 'COMEDY'::character varying, 'THEATER'::character varying, 'FILM'::character varying, 'DANCE'::character varying, 'BUSINESS'::character varying, 'TECH'::character varying, 'EDUCATION'::character varying, 'WORKSHOP'::character varying, 'SPORTS'::character varying, 'FESTIVAL'::character varying, 'SEASONAL'::character varying, 'NIGHTLIFE'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.failed_jobs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id bigint NOT NULL,
    entity_id bigint,
    entity_type character varying(120),
    type character varying(40),
    filename character varying(255),
    disk character varying(20),
    path text,
    size integer,
    mime_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    account_id bigint,
    width integer,
    height integer,
    avg_colour character varying(7),
    lqip_base64 text
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    account_id bigint NOT NULL,
    invoice_number character varying(50) NOT NULL,
    issue_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    due_date timestamp(0) without time zone,
    total_amount numeric(14,2) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    items jsonb NOT NULL,
    taxes_and_fees jsonb,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO postgres;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    id bigint NOT NULL,
    short_id character varying(32) NOT NULL,
    account_id bigint NOT NULL,
    organizer_id bigint NOT NULL,
    name character varying(255),
    structured_address jsonb,
    latitude numeric(10,7),
    longitude numeric(10,7),
    provider character varying(32),
    provider_place_id character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    raw_provider_response jsonb
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.locations_id_seq OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(40) NOT NULL,
    recipient_ids jsonb,
    sent_at timestamp without time zone,
    sent_by_user_id bigint NOT NULL,
    attendee_ids jsonb,
    product_ids jsonb,
    order_id bigint,
    status character varying(20) NOT NULL,
    send_data jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    eligibility_failures json,
    scheduled_at timestamp(0) without time zone,
    event_occurrence_id bigint
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.messages ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: order_application_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_application_fees (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(20) NOT NULL,
    payment_method character varying(50) NOT NULL,
    metadata json,
    paid_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.order_application_fees OWNER TO postgres;

--
-- Name: order_application_fees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_application_fees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_application_fees_id_seq OWNER TO postgres;

--
-- Name: order_application_fees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_application_fees_id_seq OWNED BY public.order_application_fees.id;


--
-- Name: order_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_audit_logs (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    order_id bigint NOT NULL,
    attendee_id bigint,
    action character varying(50) NOT NULL,
    old_values json,
    new_values json,
    changed_fields character varying(255),
    ip_address character varying(45),
    user_agent text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.order_audit_logs OWNER TO postgres;

--
-- Name: order_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_audit_logs_id_seq OWNER TO postgres;

--
-- Name: order_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_audit_logs_id_seq OWNED BY public.order_audit_logs.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id bigint NOT NULL,
    total_before_additions numeric(14,2) NOT NULL,
    quantity integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    item_name character varying,
    price numeric(14,2) NOT NULL,
    price_before_discount numeric(14,2),
    deleted_at timestamp without time zone,
    total_tax numeric(14,2) DEFAULT 0.00 NOT NULL,
    total_gross numeric(14,2),
    total_service_fee numeric(14,2) DEFAULT 0.00,
    taxes_and_fees_rollup jsonb,
    product_price_id integer NOT NULL,
    product_type character varying(255) DEFAULT 'TICKET'::character varying NOT NULL,
    event_occurrence_id bigint
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.order_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: order_payment_platform_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_payment_platform_fees (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    payment_platform character varying(50) NOT NULL,
    fee_rollup jsonb,
    payment_platform_fee_amount numeric(10,2) NOT NULL,
    application_fee_gross_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    transaction_id character varying(255),
    paid_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    application_fee_net_amount numeric(10,2),
    application_fee_vat_amount numeric(10,2),
    charge_id character varying(255),
    application_fee_vat_rate numeric(5,4)
);


ALTER TABLE public.order_payment_platform_fees OWNER TO postgres;

--
-- Name: order_payment_platform_fees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_payment_platform_fees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_payment_platform_fees_id_seq OWNER TO postgres;

--
-- Name: order_payment_platform_fees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_payment_platform_fees_id_seq OWNED BY public.order_payment_platform_fees.id;


--
-- Name: order_refunds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_refunds (
    id integer NOT NULL,
    order_id bigint NOT NULL,
    payment_provider character varying(255) NOT NULL,
    refund_id character varying(255) NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency character varying(10) NOT NULL,
    status character varying(20),
    reason text,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.order_refunds OWNER TO postgres;

--
-- Name: COLUMN order_refunds.refund_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.order_refunds.refund_id IS 'The refund ID from the payment provider';


--
-- Name: order_refunds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_refunds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_refunds_id_seq OWNER TO postgres;

--
-- Name: order_refunds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_refunds_id_seq OWNED BY public.order_refunds.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    short_id character varying(20) NOT NULL,
    event_id integer NOT NULL,
    total_before_additions numeric(14,2) DEFAULT 0.00 NOT NULL,
    total_refunded numeric(14,2) DEFAULT 0.00 NOT NULL,
    total_gross numeric(14,2) DEFAULT 0.00 NOT NULL,
    currency character varying(3) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(255),
    status character varying NOT NULL,
    payment_status character varying,
    refund_status character varying,
    reserved_until timestamp(0) without time zone,
    is_manually_created boolean DEFAULT false NOT NULL,
    session_id character varying(40),
    public_id character varying NOT NULL,
    point_in_time_data jsonb,
    payment_gateway character varying,
    promo_code_id integer,
    promo_code character varying,
    address jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    taxes_and_fees_rollup jsonb,
    total_tax numeric(14,2) DEFAULT 0.00 NOT NULL,
    total_fee numeric(14,2) DEFAULT 0.00 NOT NULL,
    locale character varying(20) DEFAULT 'en'::character varying NOT NULL,
    payment_provider character varying(255),
    notes text,
    affiliate_id bigint,
    statistics_decremented_at timestamp(0) without time zone,
    opted_into_marketing_at timestamp(0) without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.orders ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organizer_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizer_configurations (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    is_system_default boolean DEFAULT false NOT NULL,
    application_fees json,
    bypass_application_fees boolean DEFAULT false NOT NULL,
    legacy_account_configuration_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.organizer_configurations OWNER TO postgres;

--
-- Name: organizer_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizer_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizer_configurations_id_seq OWNER TO postgres;

--
-- Name: organizer_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizer_configurations_id_seq OWNED BY public.organizer_configurations.id;


--
-- Name: organizer_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizer_settings (
    id bigint NOT NULL,
    social_media_handles jsonb,
    website_url character varying(255),
    homepage_theme_settings jsonb,
    homepage_visibility character varying(255) DEFAULT 'PUBLIC'::character varying NOT NULL,
    homepage_password character varying(255),
    seo_keywords character varying(255),
    seo_title character varying(355),
    seo_description text,
    allow_search_engine_indexing boolean DEFAULT true NOT NULL,
    organizer_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    location_details jsonb,
    default_attendee_details_collection_method character varying(255) DEFAULT 'PER_TICKET'::character varying NOT NULL,
    default_show_marketing_opt_in boolean DEFAULT true NOT NULL,
    default_pass_platform_fee_to_buyer boolean DEFAULT false NOT NULL,
    default_allow_attendee_self_edit boolean DEFAULT true NOT NULL,
    tracking_pixels jsonb,
    tracking_consent_acknowledged boolean DEFAULT false NOT NULL
);


ALTER TABLE public.organizer_settings OWNER TO postgres;

--
-- Name: organizer_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizer_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizer_settings_id_seq OWNER TO postgres;

--
-- Name: organizer_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizer_settings_id_seq OWNED BY public.organizer_settings.id;


--
-- Name: organizer_stripe_platforms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizer_stripe_platforms (
    id bigint NOT NULL,
    organizer_id bigint NOT NULL,
    stripe_connect_account_type character varying(255),
    stripe_connect_platform character varying(2),
    stripe_account_id character varying(255),
    stripe_setup_completed_at timestamp(0) without time zone,
    stripe_account_details jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.organizer_stripe_platforms OWNER TO postgres;

--
-- Name: organizer_stripe_platforms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizer_stripe_platforms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizer_stripe_platforms_id_seq OWNER TO postgres;

--
-- Name: organizer_stripe_platforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizer_stripe_platforms_id_seq OWNED BY public.organizer_stripe_platforms.id;


--
-- Name: organizer_vat_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizer_vat_settings (
    id bigint NOT NULL,
    organizer_id bigint NOT NULL,
    vat_registered boolean DEFAULT false NOT NULL,
    vat_number character varying(20),
    vat_validated boolean DEFAULT false NOT NULL,
    vat_validation_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    vat_validation_error text,
    vat_validation_attempts integer DEFAULT 0 NOT NULL,
    vat_validation_date timestamp(0) without time zone,
    business_name character varying(255),
    business_address character varying(255),
    vat_country_code character varying(2),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.organizer_vat_settings OWNER TO postgres;

--
-- Name: organizer_vat_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizer_vat_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizer_vat_settings_id_seq OWNER TO postgres;

--
-- Name: organizer_vat_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizer_vat_settings_id_seq OWNED BY public.organizer_vat_settings.id;


--
-- Name: organizers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizers (
    id bigint NOT NULL,
    account_id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(20),
    website character varying(255),
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    organizer_configuration_id bigint,
    location_id bigint
);


ALTER TABLE public.organizers OWNER TO postgres;

--
-- Name: organizers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.organizers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organizers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: outgoing_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.outgoing_messages (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    message_id bigint NOT NULL,
    subject character varying(255) NOT NULL,
    recipient character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.outgoing_messages OWNER TO postgres;

--
-- Name: outgoing_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.outgoing_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.outgoing_messages_id_seq OWNER TO postgres;

--
-- Name: outgoing_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.outgoing_messages_id_seq OWNED BY public.outgoing_messages.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp without time zone,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    id bigint NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.password_reset_tokens ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.password_reset_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    email character varying(200),
    token character varying(200),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    id bigint NOT NULL,
    ip_address character varying NOT NULL,
    user_agent character varying
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- Name: password_resets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.password_resets ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.password_resets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: product_addons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_addons (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    addon_product_id bigint NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT product_addons_no_self_reference CHECK ((product_id <> addon_product_id))
);


ALTER TABLE public.product_addons OWNER TO postgres;

--
-- Name: product_addons_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_addons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_addons_id_seq OWNER TO postgres;

--
-- Name: product_addons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_addons_id_seq OWNED BY public.product_addons.id;


--
-- Name: product_capacity_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_capacity_assignments (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    capacity_assignment_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.product_capacity_assignments OWNER TO postgres;

--
-- Name: product_capacity_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_capacity_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_capacity_assignments_id_seq OWNER TO postgres;

--
-- Name: product_capacity_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_capacity_assignments_id_seq OWNED BY public.product_capacity_assignments.id;


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    no_products_message character varying(255),
    description text,
    is_hidden boolean DEFAULT false NOT NULL,
    "order" smallint DEFAULT '0'::smallint NOT NULL,
    event_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: product_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_categories_id_seq OWNER TO postgres;

--
-- Name: product_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_categories_id_seq OWNED BY public.product_categories.id;


--
-- Name: product_check_in_lists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_check_in_lists (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    check_in_list_id bigint NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.product_check_in_lists OWNER TO postgres;

--
-- Name: product_check_in_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_check_in_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_check_in_lists_id_seq OWNER TO postgres;

--
-- Name: product_check_in_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_check_in_lists_id_seq OWNED BY public.product_check_in_lists.id;


--
-- Name: product_occurrence_visibility; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_occurrence_visibility (
    id bigint NOT NULL,
    event_occurrence_id bigint NOT NULL,
    product_id bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_occurrence_visibility OWNER TO postgres;

--
-- Name: product_occurrence_visibility_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_occurrence_visibility_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_occurrence_visibility_id_seq OWNER TO postgres;

--
-- Name: product_occurrence_visibility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_occurrence_visibility_id_seq OWNED BY public.product_occurrence_visibility.id;


--
-- Name: product_price_occurrence_overrides; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_price_occurrence_overrides (
    id bigint NOT NULL,
    event_occurrence_id bigint NOT NULL,
    product_price_id bigint NOT NULL,
    price numeric(14,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.product_price_occurrence_overrides OWNER TO postgres;

--
-- Name: product_price_occurrence_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_price_occurrence_overrides_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_price_occurrence_overrides_id_seq OWNER TO postgres;

--
-- Name: product_price_occurrence_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_price_occurrence_overrides_id_seq OWNED BY public.product_price_occurrence_overrides.id;


--
-- Name: product_prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_prices (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    price numeric(14,2) NOT NULL,
    label character varying(255),
    sale_start_date timestamp without time zone,
    sale_end_date timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    initial_quantity_available integer,
    quantity_sold integer DEFAULT 0 NOT NULL,
    is_hidden boolean DEFAULT false,
    "order" integer DEFAULT 1 NOT NULL,
    quantity_available integer,
    CONSTRAINT valid_price_range CHECK ((price >= (0)::numeric))
);


ALTER TABLE public.product_prices OWNER TO postgres;

--
-- Name: product_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_questions (
    id integer NOT NULL,
    product_id integer NOT NULL,
    question_id integer NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.product_questions OWNER TO postgres;

--
-- Name: product_taxes_and_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_taxes_and_fees (
    id integer NOT NULL,
    product_id bigint NOT NULL,
    tax_and_fee_id bigint NOT NULL
);


ALTER TABLE public.product_taxes_and_fees OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    event_id integer NOT NULL,
    sale_start_date timestamp without time zone,
    sale_end_date timestamp without time zone,
    max_per_order integer,
    description text,
    min_per_order integer,
    sales_volume numeric(14,2) DEFAULT 0.00 NOT NULL,
    sales_tax_volume numeric(14,2) DEFAULT 0.00 NOT NULL,
    hide_before_sale_start_date boolean DEFAULT false NOT NULL,
    hide_after_sale_end_date boolean DEFAULT false NOT NULL,
    hide_when_sold_out boolean DEFAULT false NOT NULL,
    show_quantity_remaining boolean DEFAULT false NOT NULL,
    is_hidden_without_promo_code boolean DEFAULT false NOT NULL,
    "order" integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    type character varying(20) DEFAULT 'PAID'::character varying NOT NULL,
    is_hidden boolean DEFAULT false,
    product_type character varying(255) DEFAULT 'TICKET'::character varying NOT NULL,
    product_category_id bigint,
    start_collapsed boolean DEFAULT false NOT NULL,
    is_highlighted boolean DEFAULT false NOT NULL,
    highlight_message character varying(255),
    waitlist_enabled boolean,
    is_addon_only boolean DEFAULT false NOT NULL,
    CONSTRAINT products_product_type_check CHECK (((product_type)::text = ANY ((ARRAY['TICKET'::character varying, 'GENERAL'::character varying])::text[])))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_codes (
    id bigint NOT NULL,
    code character varying(50) NOT NULL,
    discount numeric(14,2) DEFAULT 0.00 NOT NULL,
    applicable_product_ids jsonb,
    expiry_date timestamp with time zone,
    event_id bigint NOT NULL,
    discount_type character varying,
    attendee_usage_count integer DEFAULT 0 NOT NULL,
    order_usage_count integer DEFAULT 0 NOT NULL,
    max_allowed_usages integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    discount_applies_to character varying(255) DEFAULT 'EACH_PRODUCT'::character varying NOT NULL
);


ALTER TABLE public.promo_codes OWNER TO postgres;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.promo_codes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.promo_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: question_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question_answers (
    id bigint NOT NULL,
    question_id integer NOT NULL,
    order_id integer NOT NULL,
    attendee_id integer,
    product_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    answer jsonb
);


ALTER TABLE public.question_answers OWNER TO postgres;

--
-- Name: questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.questions (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    title text NOT NULL,
    required boolean DEFAULT false NOT NULL,
    type character varying,
    options jsonb,
    belongs_to character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    "order" integer DEFAULT 1 NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    description text
);


ALTER TABLE public.questions OWNER TO postgres;

--
-- Name: question_and_answer_views; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.question_and_answer_views AS
 SELECT qa.id AS question_answer_id,
    p.id AS product_id,
    p.title AS product_title,
    q.id AS question_id,
    q.event_id,
    q.belongs_to,
    q.type AS question_type,
    a.first_name,
    a.last_name,
    a.public_id AS attendee_public_id,
    a.email AS attendee_email,
    a.id AS attendee_id,
    o.id AS order_id,
    o.public_id AS order_public_id,
    o.first_name AS order_first_name,
    o.last_name AS order_last_name,
    o.email AS order_email,
    q.title,
    q.description AS question_description,
    q.required AS question_required,
    q.options AS question_options,
    qa.answer
   FROM ((((public.question_answers qa
     LEFT JOIN public.attendees a ON ((a.id = qa.attendee_id)))
     LEFT JOIN public.products p ON ((p.id = qa.product_id)))
     LEFT JOIN public.orders o ON ((qa.order_id = o.id)))
     JOIN public.questions q ON ((q.id = qa.question_id)));


ALTER VIEW public.question_and_answer_views OWNER TO postgres;

--
-- Name: question_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.question_answers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.question_answers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.questions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.questions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying,
    permissions jsonb NOT NULL,
    account_id bigint
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.roles ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stripe_customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stripe_customers (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    stripe_customer_id character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    stripe_account_id character varying(255)
);


ALTER TABLE public.stripe_customers OWNER TO postgres;

--
-- Name: stripe_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stripe_customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stripe_customers_id_seq OWNER TO postgres;

--
-- Name: stripe_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stripe_customers_id_seq OWNED BY public.stripe_customers.id;


--
-- Name: stripe_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stripe_payments (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    payment_intent_id character varying NOT NULL,
    charge_id character varying,
    payment_method_id character varying,
    amount_received bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    last_error json,
    connected_account_id character varying(50),
    application_fee_gross bigint DEFAULT '0'::bigint NOT NULL,
    stripe_platform character varying(2),
    application_fee_net bigint,
    application_fee_vat bigint,
    currency character varying(10),
    payout_id character varying(255),
    payout_stripe_fee bigint,
    payout_net_amount bigint,
    payout_currency character varying(10),
    payout_exchange_rate numeric(20,10),
    balance_transaction_id character varying(255),
    application_fee_vat_rate numeric(5,4)
);


ALTER TABLE public.stripe_payments OWNER TO postgres;

--
-- Name: stripe_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.stripe_payments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.stripe_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stripe_payouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stripe_payouts (
    id bigint NOT NULL,
    payout_id character varying(255) NOT NULL,
    stripe_platform character varying(255),
    amount_minor bigint,
    currency character varying(10),
    payout_date timestamp(0) without time zone,
    payout_status character varying(50),
    total_application_fee_vat_minor bigint,
    total_application_fee_net_minor bigint,
    metadata jsonb,
    reconciled boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.stripe_payouts OWNER TO postgres;

--
-- Name: stripe_payouts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stripe_payouts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stripe_payouts_id_seq OWNER TO postgres;

--
-- Name: stripe_payouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stripe_payouts_id_seq OWNED BY public.stripe_payouts.id;


--
-- Name: taxes_and_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.taxes_and_fees (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    calculation_type character varying(20) NOT NULL,
    rate numeric(10,3) NOT NULL,
    is_active boolean DEFAULT true,
    description text,
    created_at timestamp without time zone,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    account_id bigint NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    type character varying(20) NOT NULL,
    CONSTRAINT calculation_method_check CHECK (((calculation_type)::text = ANY (ARRAY[('FIXED'::character varying)::text, ('PERCENTAGE'::character varying)::text]))),
    CONSTRAINT type_check CHECK (((type)::text = ANY (ARRAY[('TAX'::character varying)::text, ('FEE'::character varying)::text])))
);


ALTER TABLE public.taxes_and_fees OWNER TO postgres;

--
-- Name: COLUMN taxes_and_fees.is_default; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.taxes_and_fees.is_default IS 'Whether to apply to all new tickets automatically';


--
-- Name: taxes_and_fees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.taxes_and_fees ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.taxes_and_fees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ticket_lookup_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_lookup_tokens (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.ticket_lookup_tokens OWNER TO postgres;

--
-- Name: ticket_lookup_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_lookup_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_lookup_tokens_id_seq OWNER TO postgres;

--
-- Name: ticket_lookup_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_lookup_tokens_id_seq OWNED BY public.ticket_lookup_tokens.id;


--
-- Name: ticket_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.product_prices ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ticket_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ticket_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_questions_id_seq OWNER TO postgres;

--
-- Name: ticket_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_questions_id_seq OWNED BY public.product_questions.id;


--
-- Name: ticket_taxes_and_fees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.product_taxes_and_fees ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ticket_taxes_and_fees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.products ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: timezones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.timezones (
    id bigint NOT NULL,
    name character varying(64) NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.timezones OWNER TO postgres;

--
-- Name: timezones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.timezones ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.timezones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp without time zone,
    first_name character varying NOT NULL,
    last_name character varying,
    pending_email character varying,
    timezone character varying NOT NULL,
    locale character varying(20) DEFAULT 'en'::character varying NOT NULL,
    marketing_opted_in_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: waitlist_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waitlist_entries (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    product_price_id bigint NOT NULL,
    email character varying(255) NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255),
    status character varying(50) NOT NULL,
    offer_token character varying(100),
    cancel_token character varying(100),
    offered_at timestamp(0) without time zone,
    offer_expires_at timestamp(0) without time zone,
    purchased_at timestamp(0) without time zone,
    cancelled_at timestamp(0) without time zone,
    order_id bigint,
    "position" integer DEFAULT 0 NOT NULL,
    locale character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    event_occurrence_id bigint
);


ALTER TABLE public.waitlist_entries OWNER TO postgres;

--
-- Name: waitlist_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.waitlist_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.waitlist_entries_id_seq OWNER TO postgres;

--
-- Name: waitlist_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.waitlist_entries_id_seq OWNED BY public.waitlist_entries.id;


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook_logs (
    id bigint NOT NULL,
    payload text NOT NULL,
    event_type character varying(255) NOT NULL,
    response_code integer,
    response_body text,
    webhook_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.webhook_logs OWNER TO postgres;

--
-- Name: webhook_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.webhook_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webhook_logs_id_seq OWNER TO postgres;

--
-- Name: webhook_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.webhook_logs_id_seq OWNED BY public.webhook_logs.id;


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhooks (
    id bigint NOT NULL,
    url character varying(255) NOT NULL,
    event_types jsonb NOT NULL,
    last_response_code integer,
    last_response_body text,
    last_triggered_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'ENABLED'::character varying NOT NULL,
    secret character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint,
    account_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    organizer_id bigint
);


ALTER TABLE public.webhooks OWNER TO postgres;

--
-- Name: webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webhooks_id_seq OWNER TO postgres;

--
-- Name: webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.webhooks_id_seq OWNED BY public.webhooks.id;


--
-- Name: account_attributions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_attributions ALTER COLUMN id SET DEFAULT nextval('public.account_attributions_id_seq'::regclass);


--
-- Name: account_configuration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_configuration ALTER COLUMN id SET DEFAULT nextval('public.account_configuration_id_seq'::regclass);


--
-- Name: account_deletion_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_deletion_requests ALTER COLUMN id SET DEFAULT nextval('public.account_deletion_requests_id_seq'::regclass);


--
-- Name: account_messaging_tiers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_messaging_tiers ALTER COLUMN id SET DEFAULT nextval('public.account_messaging_tiers_id_seq'::regclass);


--
-- Name: account_stripe_platforms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stripe_platforms ALTER COLUMN id SET DEFAULT nextval('public.account_stripe_platforms_id_seq'::regclass);


--
-- Name: account_vat_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_vat_settings ALTER COLUMN id SET DEFAULT nextval('public.account_vat_settings_id_seq'::regclass);


--
-- Name: affiliates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affiliates ALTER COLUMN id SET DEFAULT nextval('public.affiliates_id_seq'::regclass);


--
-- Name: announcement_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_users ALTER COLUMN id SET DEFAULT nextval('public.announcement_users_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: attendee_check_ins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins ALTER COLUMN id SET DEFAULT nextval('public.attendee_check_ins_id_seq'::regclass);


--
-- Name: capacity_assignments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.capacity_assignments ALTER COLUMN id SET DEFAULT nextval('public.capacity_assignments_id_seq'::regclass);


--
-- Name: check_in_lists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_in_lists ALTER COLUMN id SET DEFAULT nextval('public.check_in_lists_id_seq'::regclass);


--
-- Name: email_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates ALTER COLUMN id SET DEFAULT nextval('public.email_templates_id_seq'::regclass);


--
-- Name: event_locations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_locations ALTER COLUMN id SET DEFAULT nextval('public.event_locations_id_seq'::regclass);


--
-- Name: event_occurrence_daily_statistics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_daily_statistics ALTER COLUMN id SET DEFAULT nextval('public.event_occurrence_daily_statistics_id_seq'::regclass);


--
-- Name: event_occurrence_statistics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_statistics ALTER COLUMN id SET DEFAULT nextval('public.event_occurrence_statistics_id_seq'::regclass);


--
-- Name: event_occurrences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrences ALTER COLUMN id SET DEFAULT nextval('public.event_occurrences_id_seq'::regclass);


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: order_application_fees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_application_fees ALTER COLUMN id SET DEFAULT nextval('public.order_application_fees_id_seq'::regclass);


--
-- Name: order_audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.order_audit_logs_id_seq'::regclass);


--
-- Name: order_payment_platform_fees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_payment_platform_fees ALTER COLUMN id SET DEFAULT nextval('public.order_payment_platform_fees_id_seq'::regclass);


--
-- Name: order_refunds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_refunds ALTER COLUMN id SET DEFAULT nextval('public.order_refunds_id_seq'::regclass);


--
-- Name: organizer_configurations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_configurations ALTER COLUMN id SET DEFAULT nextval('public.organizer_configurations_id_seq'::regclass);


--
-- Name: organizer_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_settings ALTER COLUMN id SET DEFAULT nextval('public.organizer_settings_id_seq'::regclass);


--
-- Name: organizer_stripe_platforms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_stripe_platforms ALTER COLUMN id SET DEFAULT nextval('public.organizer_stripe_platforms_id_seq'::regclass);


--
-- Name: organizer_vat_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_vat_settings ALTER COLUMN id SET DEFAULT nextval('public.organizer_vat_settings_id_seq'::regclass);


--
-- Name: outgoing_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.outgoing_messages ALTER COLUMN id SET DEFAULT nextval('public.outgoing_messages_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: product_addons id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_addons ALTER COLUMN id SET DEFAULT nextval('public.product_addons_id_seq'::regclass);


--
-- Name: product_capacity_assignments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_capacity_assignments ALTER COLUMN id SET DEFAULT nextval('public.product_capacity_assignments_id_seq'::regclass);


--
-- Name: product_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories ALTER COLUMN id SET DEFAULT nextval('public.product_categories_id_seq'::regclass);


--
-- Name: product_check_in_lists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_check_in_lists ALTER COLUMN id SET DEFAULT nextval('public.product_check_in_lists_id_seq'::regclass);


--
-- Name: product_occurrence_visibility id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_occurrence_visibility ALTER COLUMN id SET DEFAULT nextval('public.product_occurrence_visibility_id_seq'::regclass);


--
-- Name: product_price_occurrence_overrides id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_price_occurrence_overrides ALTER COLUMN id SET DEFAULT nextval('public.product_price_occurrence_overrides_id_seq'::regclass);


--
-- Name: product_questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_questions ALTER COLUMN id SET DEFAULT nextval('public.ticket_questions_id_seq'::regclass);


--
-- Name: stripe_customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_customers ALTER COLUMN id SET DEFAULT nextval('public.stripe_customers_id_seq'::regclass);


--
-- Name: stripe_payouts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_payouts ALTER COLUMN id SET DEFAULT nextval('public.stripe_payouts_id_seq'::regclass);


--
-- Name: ticket_lookup_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_lookup_tokens ALTER COLUMN id SET DEFAULT nextval('public.ticket_lookup_tokens_id_seq'::regclass);


--
-- Name: waitlist_entries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries ALTER COLUMN id SET DEFAULT nextval('public.waitlist_entries_id_seq'::regclass);


--
-- Name: webhook_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_logs ALTER COLUMN id SET DEFAULT nextval('public.webhook_logs_id_seq'::regclass);


--
-- Name: webhooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_id_seq'::regclass);


--
-- Data for Name: account_attributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_attributions (id, account_id, utm_source, utm_medium, utm_campaign, utm_term, utm_content, referrer_url, landing_page, gclid, fbclid, source_type, utm_raw, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_configuration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_configuration (id, name, is_system_default, application_fees, created_at, updated_at, deleted_at, bypass_application_fees) FROM stdin;
1	Default	t	{"percentage":1.5,"fixed":0,"currency":"USD"}	2026-09-24 18:24:30	2026-09-24 18:24:30	\N	f
\.


--
-- Data for Name: account_deletion_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_deletion_requests (id, account_id, requested_by_user_id, initiated_by, reason, status, expected_outcome, outcome, scheduled_deletion_at, reminder_sent_at, cancelled_at, cancelled_by_user_id, completed_at, deletion_manifest, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_messaging_tiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_messaging_tiers (id, name, max_messages_per_24h, max_recipients_per_message, links_allowed, created_at, updated_at, deleted_at) FROM stdin;
1	Untrusted	3	100	f	2026-09-24 18:24:30	2026-09-24 18:24:30	\N
2	Trusted	10	5000	t	2026-09-24 18:24:30	2026-09-24 18:24:30	\N
3	Premium	50	50000	t	2026-09-24 18:24:30	2026-09-24 18:24:30	\N
\.


--
-- Data for Name: account_stripe_platforms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_stripe_platforms (id, account_id, stripe_connect_account_type, stripe_connect_platform, stripe_account_id, stripe_setup_completed_at, stripe_account_details, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: account_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_users (id, account_id, user_id, role, created_at, deleted_at, updated_at, is_account_owner, invited_by_user_id, last_login_at, status) FROM stdin;
1	1	1	ADMIN	2026-09-24 18:31:29	\N	2026-09-24 18:36:37	t	\N	2026-09-24 18:36:37	ACTIVE
\.


--
-- Data for Name: account_vat_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_vat_settings (id, account_id, vat_registered, vat_number, vat_validated, vat_validation_date, business_name, business_address, vat_country_code, created_at, updated_at, deleted_at, vat_validation_status, vat_validation_error, vat_validation_attempts) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, currency_code, timezone, created_at, updated_at, deleted_at, name, email, stripe_account_id, short_id, stripe_connect_setup_complete, account_verified_at, stripe_connect_account_type, account_configuration_id, is_manually_verified, country, account_messaging_tier_id) FROM stdin;
1	BRL	America/Sao_Paulo	2026-09-24 18:31:29	2026-09-24 18:31:29	\N	Dev Sintético	dev.hievents@udf.edu.br	\N	acc_LwqNAKNcjXi4D	f	2026-09-24 18:31:29	\N	1	f	\N	3
\.


--
-- Data for Name: affiliates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.affiliates (id, event_id, account_id, name, code, email, total_sales, total_sales_gross, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: announcement_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcement_users (id, announcement_id, user_id, first_seen_at, dismissed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, title, content, status, display_type, emoji, target_type, target_account_ids, target_user_ids, cta_label, cta_url, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: attendee_check_ins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendee_check_ins (id, short_id, check_in_list_id, product_id, attendee_id, ip_address, deleted_at, created_at, updated_at, event_id, order_id, event_occurrence_id) FROM stdin;
\.


--
-- Data for Name: attendees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendees (id, short_id, first_name, last_name, email, order_id, product_id, event_id, public_id, status, checked_in_by, checked_in_at, created_at, updated_at, deleted_at, checked_out_by, product_price_id, locale, notes, event_occurrence_id) FROM stdin;
1	a_quBkDey0f1KcZ	Aluno	Sintético	aluno.sintetico@udf.edu.br	1	1	1	A-FKKZFD2	ACTIVE	\N	\N	2026-09-24 18:32:50	2026-09-24 18:32:50	\N	\N	1	pt-br	\N	1
\.


--
-- Data for Name: capacity_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.capacity_assignments (id, event_id, name, capacity, used_capacity, applies_to, status, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: check_in_lists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.check_in_lists (id, short_id, name, description, expires_at, activates_at, event_id, deleted_at, created_at, updated_at, event_occurrence_id, public_show_attendee_notes, public_show_question_answers, public_show_order_details, is_system_default) FROM stdin;
1	cil_ijw1jD03H9NQt	Default check-in	\N	\N	\N	1	\N	2026-09-24 18:31:53	2026-09-24 18:31:53	\N	f	f	f	t
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_templates (id, account_id, organizer_id, event_id, template_type, subject, body, cta, engine, is_active, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: event_daily_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_daily_statistics (id, sales_total_gross, total_tax, sales_total_before_additions, products_sold, orders_created, date, created_at, deleted_at, updated_at, total_fee, event_id, version, total_refunded, total_views, attendees_registered, orders_cancelled) FROM stdin;
1	0.00	0.00	0.00	1	1	2026-09-24	2026-09-24 18:32:50	\N	2026-09-24 18:32:50	0.00	1	0	0.00	0	1	0
\.


--
-- Data for Name: event_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_locations (id, short_id, event_id, type, location_id, online_event_connection_details, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: event_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_logs (id, user_id, type, entity_id, entity_type, ip_address, user_agent, data, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: event_occurrence_daily_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_occurrence_daily_statistics (id, event_id, event_occurrence_id, date, products_sold, attendees_registered, sales_total_gross, sales_total_before_additions, total_tax, total_fee, orders_created, orders_cancelled, total_refunded, version, created_at, updated_at, deleted_at) FROM stdin;
1	1	1	2026-09-24	1	1	0.00	0.00	0.00	0.00	1	0	0.00	0	2026-09-24 18:32:50	2026-09-24 18:32:50	\N
\.


--
-- Data for Name: event_occurrence_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_occurrence_statistics (id, event_id, event_occurrence_id, products_sold, attendees_registered, sales_total_gross, sales_total_before_additions, total_tax, total_fee, orders_created, orders_cancelled, total_refunded, version, created_at, updated_at, deleted_at) FROM stdin;
1	1	1	1	1	0.00	0.00	0.00	0.00	1	0	0.00	0	2026-09-24 18:32:50	2026-09-24 18:32:50	\N
\.


--
-- Data for Name: event_occurrences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_occurrences (id, short_id, event_id, start_date, end_date, status, capacity, used_capacity, label, is_overridden, created_at, updated_at, deleted_at, event_location_id, show_available_capacity, cancelled_attendees_count) FROM stdin;
1	oc_pmZVsq6Ynwarb	1	2026-10-15 22:00:00	2026-10-16 01:00:00	ACTIVE	\N	1	\N	f	2026-09-24 18:31:53	2026-09-24 18:32:50	\N	\N	\N	\N
\.


--
-- Data for Name: event_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_settings (id, pre_checkout_message, post_checkout_message, product_page_message, continue_button_text, email_footer_message, support_email, event_id, created_at, updated_at, deleted_at, require_attendee_details, order_timeout_in_minutes, website_url, maps_url, homepage_background_color, homepage_primary_text_color, homepage_primary_color, homepage_secondary_text_color, homepage_secondary_color, location_details, online_event_connection_details, is_online_event, allow_search_engine_indexing, seo_title, seo_description, social_media_handles, show_social_media_handles, seo_keywords, notify_organizer_of_new_orders, price_display_mode, show_share_buttons, homepage_body_background_color, homepage_background_type, enable_invoicing, invoice_label, invoice_prefix, invoice_start_number, require_billing_address, organization_name, organization_address, invoice_tax_details, payment_providers, offline_payment_instructions, allow_orders_awaiting_offline_payment_to_check_in, invoice_payment_terms_days, invoice_notes, ticket_design_settings, attendee_details_collection_method, show_marketing_opt_in, homepage_theme_settings, pass_platform_fee_to_buyer, allow_attendee_self_edit, waitlist_enabled, waitlist_auto_process, waitlist_offer_timeout_minutes, allow_copy_details_to_all_attendees, show_available_occurrence_capacity, hide_sold_out_occurrences, get_tickets_button_text) FROM stdin;
1	\N	\N	\N	Continuar	\N	eventos@udf.edu.br	1	2026-09-24 18:31:53	2026-09-24 18:31:53	\N	t	15	\N	\N	#ffffff	#000000	#8b5cf6	#ffffff	#8b5cf6	\N	\N	f	t	\N	\N	\N	\N	\N	t	INCLUSIVE	t	#f5f3ff	COLOR	f	Fatura	INV-	1	f	Centro Universitário (sintético)	\N	\N	["STRIPE"]	\N	f	\N	\N	{"accent_color": "#8b5cf6"}	PER_ORDER	t	{"mode": "light", "accent": "#8b5cf6", "background": "#f5f3ff", "background_type": "COLOR"}	t	t	f	t	120	t	f	f	\N
\.


--
-- Data for Name: event_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_statistics (id, event_id, unique_views, total_views, sales_total_gross, total_tax, sales_total_before_additions, created_at, deleted_at, updated_at, total_fee, products_sold, version, orders_created, total_refunded, attendees_registered, orders_cancelled) FROM stdin;
1	1	0	0	0.00	0.00	0.00	2026-09-24 18:31:53	\N	2026-09-24 18:32:50	0.00	1	1	1	0.00	1	0
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, title, account_id, user_id, start_date, end_date, description, status, location_details, currency, timezone, attributes, created_at, updated_at, deleted_at, location, organizer_id, short_id, ticket_quantity_available, category, type, recurrence_rule, event_location_id) FROM stdin;
1	Semana de Extensão (sintético)	1	1	\N	\N	<p>Evento sintético para avaliação. Não é um evento real.</p>	LIVE	\N	BRL	America/Sao_Paulo	[{"name": "ODS", "value": "1 - Erradicação da pobreza", "is_public": true}]	2026-09-24 18:31:53	2026-09-24 18:31:54	\N	\N	1	e_4UU3jKYBATo4F	\N	OTHER	SINGLE	\N	\N
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, entity_id, entity_type, type, filename, disk, path, size, mime_type, created_at, updated_at, deleted_at, account_id, width, height, avg_colour, lqip_base64) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, order_id, account_id, invoice_number, issue_date, due_date, total_amount, status, items, taxes_and_fees, uuid, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (id, short_id, account_id, organizer_id, name, structured_address, latitude, longitude, provider, provider_place_id, created_at, updated_at, deleted_at, raw_provider_response) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, event_id, subject, message, type, recipient_ids, sent_at, sent_by_user_id, attendee_ids, product_ids, order_id, status, send_data, created_at, updated_at, deleted_at, eligibility_failures, scheduled_at, event_occurrence_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2020_01_25_113926_initial_db	1
2	2024_05_16_222520_update_homepage_background_settings	1
3	2024_06_16_143927_add_locale_to_users	1
4	2024_06_16_192150_add_locale_to_attendees	1
5	2024_06_16_192151_add_locale_to_orders	1
6	2024_07_11_223142_add_description_to_questions_table	1
7	2024_07_14_031511_create_capacity_assignments_and_associated_tables	1
8	2024_07_19_033929_add_missing_indexes	1
9	2024_08_07_005807_create_stripe_customers_table	1
10	2024_08_08_032637_create_check_in_lists_tables	1
11	2024_08_17_140325_add_event_id_to_attendee_check_ins	1
12	2024_09_20_032323_rename_tickets_to_products	1
13	2024_09_20_032838_add_product_type_to_products	1
14	2024_09_23_032009_add_product_categories_table	1
15	2024_09_29_053757_add_product_type_to_order_items_table	1
16	2024_10_01_003655_update_question_and_answer_views_view	1
17	2024_10_02_031052_add_attendees_registered_to_event_statistics_tables	1
18	2024_10_14_232118_add_start_collapsed_to_tickets	1
19	2024_11_22_235559_update_capacity_assignment_applies_to	1
20	2024_12_09_234323_add_notes_to_attendees_table	1
21	2024_12_14_000001_create_account_attributions_table	1
22	2025_01_01_232333_add_event_invoicing_settings	1
23	2025_01_03_010511_create_invoices_table	1
24	2025_01_03_013621_add_payment_provider_to_orders_table	1
25	2025_01_10_144325_add_index_to_orders_status	1
26	2025_01_16_034331_add_allow_orders_awaiting_offline_payment_to_check_in_to_event_settings	1
27	2025_01_19_042750_add_notes_to_orders_table	1
28	2025_01_19_181257_add_payment_terms_and_notes_to_invoices_table	1
29	2025_01_20_035401_add_default_payment_provider	1
30	2025_01_20_045159_add_configuration_to_accounts	1
31	2025_02_02_093202_create_order_refunds_table	1
32	2025_02_03_112136_add_stripe_connect_account_type_to_accounts	1
33	2025_02_03_121516_add_stripe_account_id_to_stripe_customers_table	1
34	2025_02_09_074739_create_webhooks_table	1
35	2025_02_16_162629_add_application_fee_to_stripe_payments	1
36	2025_02_16_163546_create_account_configuration	1
37	2025_02_17_095041_create_order_application_fees_table	1
38	2025_02_23_181633_add_is_manually_verified_to_accounts	1
39	2025_02_28_112829_update_question_and_answers_view	1
40	2025_03_07_160427_add_missing_indexes	1
41	2025_03_09_085509_update_question_and_answer_view	1
42	2025_03_09_193848_create_job_batches_table	1
43	2025_03_16_143442_add_order_id_to_attendee_check_ins	1
44	2025_03_24_052900_add_outgoing_messages_table	1
45	2025_05_21_020658_add_account_id_to_images	1
46	2025_05_22_235244_create_organizer_settings_table	1
47	2025_05_26_000000_add_location_details_to_organizer_settings	1
48	2025_06_05_132644_add_status_to_organizers	1
49	2025_06_18_033649_recreate_affiliates_table	1
50	2025_06_21_060905_add_category_to_events_table	1
51	2025_06_24_055432_change_proudct_category_description_type	1
52	2025_08_27_192754_add_statistics_decremented_at_to_orders_table	1
53	2025_08_27_193114_add_orders_cancelled_to_event_statistics_tables	1
54	2025_08_28_100704_create_email_templates_table	1
55	2025_09_04_071235_add_ticket_design_settings_to_event_settings	1
56	2025_10_02_084321_create_account_stripe_platforms_table	1
57	2025_10_02_103604_add_platform_to_stripe_payments_table	1
58	2025_10_02_104751_backfill_stripe_payments_platform	1
59	2025_10_30_081843_create_order_payment_platform_fees_table	1
60	2025_11_06_134601_add_create_account_vat_settings	1
61	2025_11_07_134601_add_country_to_accounts	1
62	2025_11_07_153308_backfill_account_vat_settings	1
63	2025_11_08_211326_update_order_payment_platform_fees_add_vat_columns	1
64	2025_11_08_212909_update_stripe_payments_add_vat_and_currency	1
65	2025_11_09_215552_add_payout_id_to_stripe_payments	1
66	2025_11_11_074035_add_enhanced_payout_reconciliation_to_stripe_payments	1
67	2025_11_11_113432_add_charge_id_to_order_payment_platform_fees	1
68	2025_11_11_200000_create_stripe_payouts_table	1
69	2025_11_25_113446_add_event_id_index_to_attendees_table	1
70	2025_11_25_120000_add_attendee_details_collection_method	1
71	2025_11_26_120000_add_marketing_opt_in_fields	1
72	2025_11_28_100000_add_homepage_theme_settings_to_event_settings	1
73	2025_11_28_100001_migrate_event_color_settings_to_json	1
74	2025_11_28_100002_migrate_organizer_color_settings_to_new_format	1
75	2025_11_28_200000_add_highlight_fields_to_products	1
76	2025_11_29_000000_create_ticket_lookup_tokens_table	1
77	2025_11_29_101052_increase_maps_url_length_in_event_settings	1
78	2025_12_04_000000_add_vat_validation_status_column	1
79	2025_12_06_100000_add_application_fee_vat_rate_columns	1
80	2025_12_07_150927_add_image_metadata_columns_to_images_table	1
81	2025_12_11_210341_add_pass_platform_fee_to_buyer_to_settings_tables	1
82	2025_12_12_080721_add_marketing_opted_in_at_to_users	1
83	2025_12_16_000000_create_order_audit_logs_table	1
84	2025_12_16_000001_add_allow_attendee_self_edit_to_event_settings	1
85	2025_12_16_000002_add_default_allow_attendee_self_edit_to_organizer_settings	1
86	2025_12_21_111333_backfill_stripe_payments_timestamps	1
87	2025_12_27_192118_backfill_stripe_payments_currency_from_orders	1
88	2025_12_30_095747_create_account_messaging_tiers_table	1
89	2025_12_30_095748_add_eligibility_failures_to_messages_table	1
90	2025_12_30_095749_add_messaging_tier_to_accounts_table	1
91	2025_12_31_000000_alter_order_audit_logs_user_agent_to_text	1
92	2026_01_21_000000_add_bypass_application_fees_to_account_configuration	1
93	2026_01_30_000000_add_currency_to_application_fees	1
94	2026_02_07_000000_add_scheduled_at_to_messages_table	1
95	2026_02_15_000001_create_waitlist_entries_table	1
96	2026_02_15_000002_add_waitlist_settings_to_event_settings_and_products	1
97	2026_02_16_000001_add_waitlist_performance_indexes	1
98	2026_02_18_000001_change_waitlist_product_id_to_product_price_id	1
99	2026_02_22_000001_add_type_and_recurrence_rule_to_events	1
100	2026_02_22_000002_create_event_occurrences_table	1
101	2026_02_22_000003_create_product_price_occurrence_overrides_table	1
102	2026_02_22_000004_create_product_occurrence_visibility_table	1
103	2026_02_22_000005_add_occurrence_id_to_order_items_attendees_checkin_lists	1
104	2026_02_22_000006_backfill_occurrences_and_drop_event_dates	1
105	2026_02_22_115000_add_organizer_id_to_webhooks_table	1
106	2026_03_15_082351_fix_product_prices_quantity_available_below_sold	1
107	2026_03_22_000001_make_check_in_lists_occurrence_id_nullable	1
108	2026_03_24_000001_add_quantity_to_price_overrides_and_drop_soft_deletes	1
109	2026_03_26_000001_create_event_occurrence_statistics_table	1
110	2026_03_26_000002_backfill_event_occurrence_statistics	1
111	2026_03_26_000003_create_event_occurrence_daily_statistics_table	1
112	2026_03_29_000001_add_event_occurrence_id_to_messages_table	1
113	2026_03_31_000001_add_event_occurrence_id_to_attendee_check_ins	1
114	2026_04_04_000001_fix_occurrence_fk_on_delete_behavior	1
115	2026_04_14_000000_add_tracking_pixels_to_organizer_settings	1
116	2026_04_20_120000_add_public_visibility_to_check_in_lists	1
117	2026_04_23_000001_add_is_system_default_to_check_in_lists	1
118	2026_04_23_000002_expand_event_category_check_constraint	1
119	2026_04_26_000001_drop_quantity_from_price_occurrence_overrides	1
120	2026_04_28_000001_add_occurrence_id_to_waitlist_entries	1
121	2026_05_11_000000_create_organizer_stripe_platforms_table	1
122	2026_05_12_000000_create_organizer_vat_settings_table	1
123	2026_05_12_000001_create_organizer_configurations_table	1
124	2026_05_18_000001_create_locations_table	1
125	2026_05_19_000001_add_location_id_to_organizers_and_backfill	1
126	2026_05_22_000001_create_event_locations_table	1
127	2026_05_22_000002_link_events_and_occurrences_to_event_locations	1
128	2026_05_22_000003_add_raw_provider_response_to_locations	1
129	2026_05_27_000001_drop_hide_getting_started_page_from_event_settings	1
130	2026_06_04_120000_add_allow_copy_details_to_all_attendees_to_event_settings	1
131	2026_07_03_000001_add_occurrence_capacity_visibility	1
132	2026_07_10_000001_backfill_occurrence_used_capacity	1
133	2026_07_12_000001_add_hide_sold_out_occurrences_to_event_settings	1
134	2026_07_19_000001_add_cancelled_attendees_count_to_event_occurrences	1
135	2026_07_20_000001_backfill_occurrence_cancelled_attendees_count	1
136	2026_07_20_000002_add_unique_attendee_check_in_index	1
137	2026_07_20_000003_add_unique_event_daily_statistics_index	1
138	2026_07_26_000000_add_discount_applies_to_to_promo_codes_table	1
139	2026_07_29_000000_create_announcements_table	1
140	2026_07_29_000001_create_account_deletion_requests_table	1
141	2026_07_29_000001_create_announcement_users_table	1
142	2026_07_30_000000_create_product_addons_table	1
143	2026_08_08_000000_add_get_tickets_button_text_to_event_settings	1
\.


--
-- Data for Name: order_application_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_application_fees (id, order_id, amount, currency, status, payment_method, metadata, paid_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_audit_logs (id, event_id, order_id, attendee_id, action, old_values, new_values, changed_fields, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, total_before_additions, quantity, order_id, product_id, item_name, price, price_before_discount, deleted_at, total_tax, total_gross, total_service_fee, taxes_and_fees_rollup, product_price_id, product_type, event_occurrence_id) FROM stdin;
1	0.00	1	1	1	Inscrição gratuita	0.00	\N	\N	0.00	0.00	0.00	[]	1	TICKET	1
\.


--
-- Data for Name: order_payment_platform_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_payment_platform_fees (id, order_id, payment_platform, fee_rollup, payment_platform_fee_amount, application_fee_gross_amount, currency, transaction_id, paid_at, deleted_at, created_at, updated_at, application_fee_net_amount, application_fee_vat_amount, charge_id, application_fee_vat_rate) FROM stdin;
\.


--
-- Data for Name: order_refunds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_refunds (id, order_id, payment_provider, refund_id, amount, currency, status, reason, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, short_id, event_id, total_before_additions, total_refunded, total_gross, currency, first_name, last_name, email, status, payment_status, refund_status, reserved_until, is_manually_created, session_id, public_id, point_in_time_data, payment_gateway, promo_code_id, promo_code, address, created_at, updated_at, deleted_at, taxes_and_fees_rollup, total_tax, total_fee, locale, payment_provider, notes, affiliate_id, statistics_decremented_at, opted_into_marketing_at) FROM stdin;
1	o_Zwa5qyJAG66Af	1	0.00	0.00	0.00	BRL	Aluno	Sintético	aluno.sintetico@udf.edu.br	COMPLETED	NO_PAYMENT_REQUIRED	\N	\N	t	\N	O-NNGBWNS	\N	\N	\N	\N	\N	2026-09-24 18:32:50	2026-09-24 18:32:50	\N	[]	0.00	0.00	pt-br	\N	\N	\N	\N	\N
\.


--
-- Data for Name: organizer_configurations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizer_configurations (id, name, is_system_default, application_fees, bypass_application_fees, legacy_account_configuration_id, created_at, updated_at, deleted_at) FROM stdin;
1	Default	t	{"percentage":1.5,"fixed":0,"currency":"USD"}	f	1	2026-09-24 18:24:31	2026-09-24 18:24:31	\N
\.


--
-- Data for Name: organizer_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizer_settings (id, social_media_handles, website_url, homepage_theme_settings, homepage_visibility, homepage_password, seo_keywords, seo_title, seo_description, allow_search_engine_indexing, organizer_id, created_at, updated_at, deleted_at, location_details, default_attendee_details_collection_method, default_show_marketing_opt_in, default_pass_platform_fee_to_buyer, default_allow_attendee_self_edit, tracking_pixels, tracking_consent_acknowledged) FROM stdin;
1	\N	\N	{"name": "Midnight", "homepage_primary_color": "#ffffffff", "homepage_secondary_color": "#b3b3b3ff", "homepage_background_color": "#737373ff", "homepage_primary_text_color": "#ffffffff", "homepage_secondary_text_color": "#ffffff", "homepage_content_background_color": "#0f172a9c"}	PUBLIC	\N	\N	\N	\N	t	1	2026-09-24 18:31:53	2026-09-24 18:31:53	\N	\N	PER_ORDER	t	t	t	\N	f
\.


--
-- Data for Name: organizer_stripe_platforms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizer_stripe_platforms (id, organizer_id, stripe_connect_account_type, stripe_connect_platform, stripe_account_id, stripe_setup_completed_at, stripe_account_details, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: organizer_vat_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizer_vat_settings (id, organizer_id, vat_registered, vat_number, vat_validated, vat_validation_status, vat_validation_error, vat_validation_attempts, vat_validation_date, business_name, business_address, vat_country_code, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: organizers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizers (id, account_id, name, email, phone, website, description, created_at, updated_at, deleted_at, currency, timezone, status, organizer_configuration_id, location_id) FROM stdin;
1	1	Centro Universitário (sintético)	eventos@udf.edu.br	\N	\N	\N	2026-09-24 18:31:53	2026-09-24 18:31:53	\N	BRL	America/Sao_Paulo	DRAFT	1	\N
\.


--
-- Data for Name: outgoing_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.outgoing_messages (id, event_id, message_id, subject, recipient, status, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at, deleted_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (email, token, created_at, updated_at, deleted_at, id, ip_address, user_agent) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_addons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_addons (id, product_id, addon_product_id, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_capacity_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_capacity_assignments (id, product_id, capacity_assignment_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, name, no_products_message, description, is_hidden, "order", event_id, created_at, updated_at, deleted_at) FROM stdin;
1	Ingressos	Não há ingressos disponíveis para este evento	\N	f	0	1	2026-09-24 18:31:53	2026-09-24 18:31:53	\N
\.


--
-- Data for Name: product_check_in_lists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_check_in_lists (id, product_id, check_in_list_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_occurrence_visibility; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_occurrence_visibility (id, event_occurrence_id, product_id, created_at) FROM stdin;
\.


--
-- Data for Name: product_price_occurrence_overrides; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_price_occurrence_overrides (id, event_occurrence_id, product_price_id, price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_prices (id, product_id, price, label, sale_start_date, sale_end_date, created_at, updated_at, deleted_at, initial_quantity_available, quantity_sold, is_hidden, "order", quantity_available) FROM stdin;
1	1	0.00	\N	\N	\N	2026-09-24 18:32:43	2026-09-24 18:32:50	\N	\N	1	f	1	\N
\.


--
-- Data for Name: product_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_questions (id, product_id, question_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_taxes_and_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_taxes_and_fees (id, product_id, tax_and_fee_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, title, event_id, sale_start_date, sale_end_date, max_per_order, description, min_per_order, sales_volume, sales_tax_volume, hide_before_sale_start_date, hide_after_sale_end_date, hide_when_sold_out, show_quantity_remaining, is_hidden_without_promo_code, "order", created_at, updated_at, deleted_at, type, is_hidden, product_type, product_category_id, start_collapsed, is_highlighted, highlight_message, waitlist_enabled, is_addon_only) FROM stdin;
1	Inscrição gratuita	1	\N	\N	5	\N	1	0.00	0.00	f	f	f	f	f	1	2026-09-24 18:32:43	2026-09-24 18:32:50	\N	FREE	f	TICKET	1	f	f	\N	\N	f
\.


--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promo_codes (id, code, discount, applicable_product_ids, expiry_date, event_id, discount_type, attendee_usage_count, order_usage_count, max_allowed_usages, created_at, updated_at, deleted_at, discount_applies_to) FROM stdin;
\.


--
-- Data for Name: question_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question_answers (id, question_id, order_id, attendee_id, product_id, created_at, updated_at, deleted_at, answer) FROM stdin;
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.questions (id, event_id, title, required, type, options, belongs_to, created_at, updated_at, deleted_at, "order", is_hidden, description) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, permissions, account_id) FROM stdin;
\.


--
-- Data for Name: stripe_customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stripe_customers (id, name, email, stripe_customer_id, created_at, updated_at, deleted_at, stripe_account_id) FROM stdin;
\.


--
-- Data for Name: stripe_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stripe_payments (id, order_id, payment_intent_id, charge_id, payment_method_id, amount_received, created_at, updated_at, deleted_at, last_error, connected_account_id, application_fee_gross, stripe_platform, application_fee_net, application_fee_vat, currency, payout_id, payout_stripe_fee, payout_net_amount, payout_currency, payout_exchange_rate, balance_transaction_id, application_fee_vat_rate) FROM stdin;
\.


--
-- Data for Name: stripe_payouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stripe_payouts (id, payout_id, stripe_platform, amount_minor, currency, payout_date, payout_status, total_application_fee_vat_minor, total_application_fee_net_minor, metadata, reconciled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: taxes_and_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.taxes_and_fees (id, name, calculation_type, rate, is_active, description, created_at, deleted_at, updated_at, account_id, is_default, type) FROM stdin;
\.


--
-- Data for Name: ticket_lookup_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_lookup_tokens (id, email, token, expires_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: timezones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.timezones (id, name, deleted_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, email_verified_at, password, remember_token, created_at, updated_at, deleted_at, first_name, last_name, pending_email, timezone, locale, marketing_opted_in_at) FROM stdin;
1	dev.hievents@udf.edu.br	2026-09-24 18:31:29	$2y$10$OitXp4PHAuZOn5NGj9n2Ueo/UffQobKgsy5dJ5P3CS/Ls55/CKOKO	\N	2026-09-24 18:31:29	2026-09-24 18:31:29	\N	Dev	Sintético	\N	America/Sao_Paulo	pt-br	\N
\.


--
-- Data for Name: waitlist_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waitlist_entries (id, event_id, product_price_id, email, first_name, last_name, status, offer_token, cancel_token, offered_at, offer_expires_at, purchased_at, cancelled_at, order_id, "position", locale, created_at, updated_at, deleted_at, event_occurrence_id) FROM stdin;
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook_logs (id, payload, event_type, response_code, response_body, webhook_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhooks (id, url, event_types, last_response_code, last_response_body, last_triggered_at, status, secret, user_id, event_id, account_id, created_at, updated_at, deleted_at, organizer_id) FROM stdin;
\.


--
-- Name: account_attributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_attributions_id_seq', 1, false);


--
-- Name: account_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_configuration_id_seq', 1, true);


--
-- Name: account_deletion_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_deletion_requests_id_seq', 1, false);


--
-- Name: account_messaging_tiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_messaging_tiers_id_seq', 3, true);


--
-- Name: account_stripe_platforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_stripe_platforms_id_seq', 1, false);


--
-- Name: account_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_users_id_seq', 1, true);


--
-- Name: account_vat_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_vat_settings_id_seq', 1, false);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, true);


--
-- Name: affiliates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.affiliates_id_seq', 1, false);


--
-- Name: announcement_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcement_users_id_seq', 1, false);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: attendee_check_ins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendee_check_ins_id_seq', 1, false);


--
-- Name: attendees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendees_id_seq', 1, true);


--
-- Name: capacity_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.capacity_assignments_id_seq', 1, false);


--
-- Name: check_in_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.check_in_lists_id_seq', 1, true);


--
-- Name: email_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_templates_id_seq', 1, false);


--
-- Name: event_daily_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_daily_statistics_id_seq', 1, true);


--
-- Name: event_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_locations_id_seq', 1, false);


--
-- Name: event_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_logs_id_seq', 1, false);


--
-- Name: event_occurrence_daily_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_occurrence_daily_statistics_id_seq', 1, true);


--
-- Name: event_occurrence_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_occurrence_statistics_id_seq', 1, true);


--
-- Name: event_occurrences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_occurrences_id_seq', 1, true);


--
-- Name: event_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_settings_id_seq', 1, true);


--
-- Name: event_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_statistics_id_seq', 1, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_id_seq', 1, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locations_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 143, true);


--
-- Name: order_application_fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_application_fees_id_seq', 1, false);


--
-- Name: order_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_audit_logs_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, true);


--
-- Name: order_payment_platform_fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_payment_platform_fees_id_seq', 1, false);


--
-- Name: order_refunds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_refunds_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, true);


--
-- Name: organizer_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizer_configurations_id_seq', 1, true);


--
-- Name: organizer_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizer_settings_id_seq', 1, true);


--
-- Name: organizer_stripe_platforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizer_stripe_platforms_id_seq', 1, false);


--
-- Name: organizer_vat_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizer_vat_settings_id_seq', 1, false);


--
-- Name: organizers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizers_id_seq', 1, true);


--
-- Name: outgoing_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.outgoing_messages_id_seq', 1, false);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: password_resets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.password_resets_id_seq', 1, false);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: product_addons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_addons_id_seq', 1, false);


--
-- Name: product_capacity_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_capacity_assignments_id_seq', 1, false);


--
-- Name: product_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_categories_id_seq', 1, true);


--
-- Name: product_check_in_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_check_in_lists_id_seq', 1, false);


--
-- Name: product_occurrence_visibility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_occurrence_visibility_id_seq', 1, false);


--
-- Name: product_price_occurrence_overrides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_price_occurrence_overrides_id_seq', 1, false);


--
-- Name: promo_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_codes_id_seq', 1, false);


--
-- Name: question_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.question_answers_id_seq', 1, false);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.questions_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: stripe_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stripe_customers_id_seq', 1, false);


--
-- Name: stripe_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stripe_payments_id_seq', 1, false);


--
-- Name: stripe_payouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stripe_payouts_id_seq', 1, false);


--
-- Name: taxes_and_fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.taxes_and_fees_id_seq', 1, false);


--
-- Name: ticket_lookup_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_lookup_tokens_id_seq', 1, false);


--
-- Name: ticket_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_prices_id_seq', 1, true);


--
-- Name: ticket_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_questions_id_seq', 1, false);


--
-- Name: ticket_taxes_and_fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_taxes_and_fees_id_seq', 1, false);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, true);


--
-- Name: timezones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.timezones_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: waitlist_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.waitlist_entries_id_seq', 1, false);


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.webhook_logs_id_seq', 1, false);


--
-- Name: webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.webhooks_id_seq', 1, false);


--
-- Name: account_attributions account_attributions_account_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_attributions
    ADD CONSTRAINT account_attributions_account_id_unique UNIQUE (account_id);


--
-- Name: account_attributions account_attributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_attributions
    ADD CONSTRAINT account_attributions_pkey PRIMARY KEY (id);


--
-- Name: account_configuration account_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_configuration
    ADD CONSTRAINT account_configuration_pkey PRIMARY KEY (id);


--
-- Name: account_deletion_requests account_deletion_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_deletion_requests
    ADD CONSTRAINT account_deletion_requests_pkey PRIMARY KEY (id);


--
-- Name: account_messaging_tiers account_messaging_tiers_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_messaging_tiers
    ADD CONSTRAINT account_messaging_tiers_name_unique UNIQUE (name);


--
-- Name: account_messaging_tiers account_messaging_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_messaging_tiers
    ADD CONSTRAINT account_messaging_tiers_pkey PRIMARY KEY (id);


--
-- Name: account_stripe_platforms account_stripe_platforms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stripe_platforms
    ADD CONSTRAINT account_stripe_platforms_pkey PRIMARY KEY (id);


--
-- Name: account_stripe_platforms account_stripe_platforms_stripe_account_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stripe_platforms
    ADD CONSTRAINT account_stripe_platforms_stripe_account_id_unique UNIQUE (stripe_account_id);


--
-- Name: account_users account_users_account_id_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_users
    ADD CONSTRAINT account_users_account_id_user_id_role_key UNIQUE (account_id, user_id, role);


--
-- Name: account_users account_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_users
    ADD CONSTRAINT account_users_pkey PRIMARY KEY (id);


--
-- Name: account_vat_settings account_vat_settings_account_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_vat_settings
    ADD CONSTRAINT account_vat_settings_account_id_unique UNIQUE (account_id);


--
-- Name: account_vat_settings account_vat_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_vat_settings
    ADD CONSTRAINT account_vat_settings_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: affiliates affiliates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affiliates
    ADD CONSTRAINT affiliates_pkey PRIMARY KEY (id);


--
-- Name: announcement_users announcement_users_announcement_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_users
    ADD CONSTRAINT announcement_users_announcement_id_user_id_unique UNIQUE (announcement_id, user_id);


--
-- Name: announcement_users announcement_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_users
    ADD CONSTRAINT announcement_users_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: attendee_check_ins attendee_check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_pkey PRIMARY KEY (id);


--
-- Name: attendees attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_pkey PRIMARY KEY (id);


--
-- Name: capacity_assignments capacity_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.capacity_assignments
    ADD CONSTRAINT capacity_assignments_pkey PRIMARY KEY (id);


--
-- Name: check_in_lists check_in_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_in_lists
    ADD CONSTRAINT check_in_lists_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: event_daily_statistics event_daily_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_daily_statistics
    ADD CONSTRAINT event_daily_statistics_pkey PRIMARY KEY (id);


--
-- Name: event_locations event_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_locations
    ADD CONSTRAINT event_locations_pkey PRIMARY KEY (id);


--
-- Name: event_locations event_locations_short_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_locations
    ADD CONSTRAINT event_locations_short_id_unique UNIQUE (short_id);


--
-- Name: event_logs event_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_logs
    ADD CONSTRAINT event_logs_pkey PRIMARY KEY (id);


--
-- Name: event_occurrence_daily_statistics event_occurrence_daily_statistics_event_occurrence_id_date_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_daily_statistics
    ADD CONSTRAINT event_occurrence_daily_statistics_event_occurrence_id_date_uniq UNIQUE (event_occurrence_id, date);


--
-- Name: event_occurrence_daily_statistics event_occurrence_daily_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_daily_statistics
    ADD CONSTRAINT event_occurrence_daily_statistics_pkey PRIMARY KEY (id);


--
-- Name: event_occurrence_statistics event_occurrence_statistics_event_occurrence_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_statistics
    ADD CONSTRAINT event_occurrence_statistics_event_occurrence_id_unique UNIQUE (event_occurrence_id);


--
-- Name: event_occurrence_statistics event_occurrence_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_statistics
    ADD CONSTRAINT event_occurrence_statistics_pkey PRIMARY KEY (id);


--
-- Name: event_occurrences event_occurrences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrences
    ADD CONSTRAINT event_occurrences_pkey PRIMARY KEY (id);


--
-- Name: event_settings event_settings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_settings
    ADD CONSTRAINT event_settings_pk PRIMARY KEY (id);


--
-- Name: event_statistics event_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_statistics
    ADD CONSTRAINT event_statistics_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: locations locations_short_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_short_id_unique UNIQUE (short_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: order_application_fees order_application_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_application_fees
    ADD CONSTRAINT order_application_fees_pkey PRIMARY KEY (id);


--
-- Name: order_audit_logs order_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_audit_logs
    ADD CONSTRAINT order_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_payment_platform_fees order_payment_platform_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_payment_platform_fees
    ADD CONSTRAINT order_payment_platform_fees_pkey PRIMARY KEY (id);


--
-- Name: order_refunds order_refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_refunds
    ADD CONSTRAINT order_refunds_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pk UNIQUE (public_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: organizer_configurations organizer_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_configurations
    ADD CONSTRAINT organizer_configurations_pkey PRIMARY KEY (id);


--
-- Name: organizer_settings organizer_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_settings
    ADD CONSTRAINT organizer_settings_pkey PRIMARY KEY (id);


--
-- Name: organizer_stripe_platforms organizer_stripe_platforms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_stripe_platforms
    ADD CONSTRAINT organizer_stripe_platforms_pkey PRIMARY KEY (id);


--
-- Name: organizer_vat_settings organizer_vat_settings_organizer_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_vat_settings
    ADD CONSTRAINT organizer_vat_settings_organizer_id_unique UNIQUE (organizer_id);


--
-- Name: organizer_vat_settings organizer_vat_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_vat_settings
    ADD CONSTRAINT organizer_vat_settings_pkey PRIMARY KEY (id);


--
-- Name: organizers organizers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizers
    ADD CONSTRAINT organizers_pkey PRIMARY KEY (id);


--
-- Name: outgoing_messages outgoing_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.outgoing_messages
    ADD CONSTRAINT outgoing_messages_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: product_prices pk_ticket_prices; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_prices
    ADD CONSTRAINT pk_ticket_prices PRIMARY KEY (id);


--
-- Name: product_occurrence_visibility pov_occurrence_product_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_occurrence_visibility
    ADD CONSTRAINT pov_occurrence_product_unique UNIQUE (event_occurrence_id, product_id);


--
-- Name: product_price_occurrence_overrides ppoo_occurrence_price_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_price_occurrence_overrides
    ADD CONSTRAINT ppoo_occurrence_price_unique UNIQUE (event_occurrence_id, product_price_id);


--
-- Name: product_addons product_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_addons
    ADD CONSTRAINT product_addons_pkey PRIMARY KEY (id);


--
-- Name: product_addons product_addons_product_id_addon_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_addons
    ADD CONSTRAINT product_addons_product_id_addon_product_id_unique UNIQUE (product_id, addon_product_id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_occurrence_visibility product_occurrence_visibility_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_occurrence_visibility
    ADD CONSTRAINT product_occurrence_visibility_pkey PRIMARY KEY (id);


--
-- Name: product_price_occurrence_overrides product_price_occurrence_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_price_occurrence_overrides
    ADD CONSTRAINT product_price_occurrence_overrides_pkey PRIMARY KEY (id);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: question_answers question_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_answers
    ADD CONSTRAINT question_answers_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pk PRIMARY KEY (id);


--
-- Name: stripe_customers stripe_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_customers
    ADD CONSTRAINT stripe_customers_pkey PRIMARY KEY (id);


--
-- Name: stripe_payments stripe_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_payments
    ADD CONSTRAINT stripe_payments_pkey PRIMARY KEY (id);


--
-- Name: stripe_payouts stripe_payouts_payout_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_payouts
    ADD CONSTRAINT stripe_payouts_payout_id_unique UNIQUE (payout_id);


--
-- Name: stripe_payouts stripe_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_payouts
    ADD CONSTRAINT stripe_payouts_pkey PRIMARY KEY (id);


--
-- Name: taxes_and_fees tax_and_fee_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taxes_and_fees
    ADD CONSTRAINT tax_and_fee_types_pkey PRIMARY KEY (id);


--
-- Name: product_capacity_assignments ticket_capacity_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_capacity_assignments
    ADD CONSTRAINT ticket_capacity_assignments_pkey PRIMARY KEY (id);


--
-- Name: product_capacity_assignments ticket_capacity_assignments_ticket_id_capacity_assignment_id_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_capacity_assignments
    ADD CONSTRAINT ticket_capacity_assignments_ticket_id_capacity_assignment_id_un UNIQUE (product_id, capacity_assignment_id);


--
-- Name: product_check_in_lists ticket_check_in_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_check_in_lists
    ADD CONSTRAINT ticket_check_in_lists_pkey PRIMARY KEY (id);


--
-- Name: ticket_lookup_tokens ticket_lookup_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_lookup_tokens
    ADD CONSTRAINT ticket_lookup_tokens_pkey PRIMARY KEY (id);


--
-- Name: ticket_lookup_tokens ticket_lookup_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_lookup_tokens
    ADD CONSTRAINT ticket_lookup_tokens_token_unique UNIQUE (token);


--
-- Name: product_questions ticket_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_questions
    ADD CONSTRAINT ticket_questions_pkey PRIMARY KEY (id);


--
-- Name: product_taxes_and_fees ticket_tax_and_fees_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_taxes_and_fees
    ADD CONSTRAINT ticket_tax_and_fees_pk PRIMARY KEY (id);


--
-- Name: products tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: timezones timezones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timezones
    ADD CONSTRAINT timezones_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waitlist_entries waitlist_entries_cancel_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_cancel_token_unique UNIQUE (cancel_token);


--
-- Name: waitlist_entries waitlist_entries_offer_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_offer_token_unique UNIQUE (offer_token);


--
-- Name: waitlist_entries waitlist_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: account_attributions_source_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_attributions_source_type_index ON public.account_attributions USING btree (source_type);


--
-- Name: account_attributions_utm_campaign_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_attributions_utm_campaign_index ON public.account_attributions USING btree (utm_campaign);


--
-- Name: account_attributions_utm_source_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_attributions_utm_source_index ON public.account_attributions USING btree (utm_source);


--
-- Name: account_deletion_requests_account_id_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_deletion_requests_account_id_status_index ON public.account_deletion_requests USING btree (account_id, status);


--
-- Name: account_deletion_requests_status_scheduled_deletion_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_deletion_requests_status_scheduled_deletion_at_index ON public.account_deletion_requests USING btree (status, scheduled_deletion_at);


--
-- Name: account_stripe_platforms_account_id_stripe_connect_platform_ind; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_stripe_platforms_account_id_stripe_connect_platform_ind ON public.account_stripe_platforms USING btree (account_id, stripe_connect_platform);


--
-- Name: account_stripe_platforms_stripe_connect_platform_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_stripe_platforms_stripe_connect_platform_index ON public.account_stripe_platforms USING btree (stripe_connect_platform);


--
-- Name: account_vat_settings_vat_number_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_vat_settings_vat_number_index ON public.account_vat_settings USING btree (vat_number);


--
-- Name: account_vat_settings_vat_validated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_vat_settings_vat_validated_index ON public.account_vat_settings USING btree (vat_validated);


--
-- Name: affiliates_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX affiliates_account_id_index ON public.affiliates USING btree (account_id);


--
-- Name: affiliates_code_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX affiliates_code_index ON public.affiliates USING btree (code);


--
-- Name: affiliates_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX affiliates_event_id_index ON public.affiliates USING btree (event_id);


--
-- Name: affiliates_event_id_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX affiliates_event_id_status_index ON public.affiliates USING btree (event_id, status);


--
-- Name: affiliates_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX affiliates_status_index ON public.affiliates USING btree (status);


--
-- Name: announcement_users_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX announcement_users_user_id_index ON public.announcement_users USING btree (user_id);


--
-- Name: announcements_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX announcements_status_index ON public.announcements USING btree (status);


--
-- Name: attendee_check_ins_attendee_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendee_check_ins_attendee_id_index ON public.attendee_check_ins USING btree (attendee_id);


--
-- Name: attendee_check_ins_check_in_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendee_check_ins_check_in_list_id_index ON public.attendee_check_ins USING btree (check_in_list_id);


--
-- Name: attendee_check_ins_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendee_check_ins_event_id_index ON public.attendee_check_ins USING btree (event_id);


--
-- Name: attendee_check_ins_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendee_check_ins_event_occurrence_id_index ON public.attendee_check_ins USING btree (event_occurrence_id);


--
-- Name: attendee_check_ins_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendee_check_ins_product_id_index ON public.attendee_check_ins USING btree (product_id);


--
-- Name: attendee_check_ins_short_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendee_check_ins_short_id_index ON public.attendee_check_ins USING btree (short_id);


--
-- Name: attendee_check_ins_unique_attendee_list; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX attendee_check_ins_unique_attendee_list ON public.attendee_check_ins USING btree (attendee_id, check_in_list_id) WHERE (deleted_at IS NULL);


--
-- Name: attendees_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendees_event_occurrence_id_index ON public.attendees USING btree (event_occurrence_id);


--
-- Name: attendees_order_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendees_order_id_index ON public.attendees USING btree (order_id);


--
-- Name: capacity_assignments_applies_to_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX capacity_assignments_applies_to_index ON public.capacity_assignments USING btree (applies_to);


--
-- Name: capacity_assignments_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX capacity_assignments_event_id_index ON public.capacity_assignments USING btree (event_id);


--
-- Name: capacity_assignments_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX capacity_assignments_status_index ON public.capacity_assignments USING btree (status);


--
-- Name: check_in_lists_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX check_in_lists_event_id_index ON public.check_in_lists USING btree (event_id);


--
-- Name: check_in_lists_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX check_in_lists_event_occurrence_id_index ON public.check_in_lists USING btree (event_occurrence_id);


--
-- Name: check_in_lists_one_default_per_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX check_in_lists_one_default_per_event ON public.check_in_lists USING btree (event_id) WHERE ((is_system_default = true) AND (deleted_at IS NULL));


--
-- Name: check_in_lists_short_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX check_in_lists_short_id_index ON public.check_in_lists USING btree (short_id);


--
-- Name: email_templates_account_id_template_type_is_active_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX email_templates_account_id_template_type_is_active_index ON public.email_templates USING btree (account_id, template_type, is_active);


--
-- Name: email_templates_event_id_template_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX email_templates_event_id_template_type_index ON public.email_templates USING btree (event_id, template_type);


--
-- Name: email_templates_organizer_id_template_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX email_templates_organizer_id_template_type_index ON public.email_templates USING btree (organizer_id, template_type);


--
-- Name: event_daily_statistics_event_id_date_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX event_daily_statistics_event_id_date_uniq ON public.event_daily_statistics USING btree (event_id, date) WHERE (deleted_at IS NULL);


--
-- Name: event_daily_statistics_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_daily_statistics_event_id_index ON public.event_daily_statistics USING btree (event_id);


--
-- Name: event_locations_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_locations_event_id_index ON public.event_locations USING btree (event_id);


--
-- Name: event_occurrence_daily_statistics_event_id_date_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrence_daily_statistics_event_id_date_index ON public.event_occurrence_daily_statistics USING btree (event_id, date);


--
-- Name: event_occurrence_statistics_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrence_statistics_event_id_index ON public.event_occurrence_statistics USING btree (event_id);


--
-- Name: event_occurrences_event_id_start_date_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrences_event_id_start_date_index ON public.event_occurrences USING btree (event_id, start_date);


--
-- Name: event_occurrences_event_location_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrences_event_location_id_index ON public.event_occurrences USING btree (event_location_id);


--
-- Name: event_occurrences_short_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrences_short_id_index ON public.event_occurrences USING btree (short_id);


--
-- Name: event_occurrences_start_date_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrences_start_date_index ON public.event_occurrences USING btree (start_date);


--
-- Name: event_occurrences_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_occurrences_status_index ON public.event_occurrences USING btree (status);


--
-- Name: event_settings_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_settings_event_id_index ON public.event_settings USING btree (event_id);


--
-- Name: event_statistics_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_statistics_event_id_index ON public.event_statistics USING btree (event_id);


--
-- Name: events_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_account_id_index ON public.events USING btree (account_id);


--
-- Name: events_event_location_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_location_id_index ON public.events USING btree (event_location_id);


--
-- Name: events_organizer_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_organizer_id_index ON public.events USING btree (organizer_id);


--
-- Name: events_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_user_id_index ON public.events USING btree (user_id);


--
-- Name: idx_account_users_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_account_users_account_id ON public.account_users USING btree (account_id);


--
-- Name: idx_account_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_account_users_role ON public.account_users USING btree (role);


--
-- Name: idx_account_users_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_account_users_user_id ON public.account_users USING btree (user_id);


--
-- Name: idx_attendee_check_ins_attendee_id_check_in_list_id_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendee_check_ins_attendee_id_check_in_list_id_deleted_at ON public.attendee_check_ins USING btree (attendee_id, check_in_list_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_attendees_email_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_email_trgm ON public.attendees USING gin (email public.gin_trgm_ops);


--
-- Name: idx_attendees_event_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_event_id ON public.attendees USING btree (event_id);


--
-- Name: idx_attendees_first_name_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_first_name_trgm ON public.attendees USING gin (first_name public.gin_trgm_ops);


--
-- Name: idx_attendees_last_name_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_last_name_trgm ON public.attendees USING gin (last_name public.gin_trgm_ops);


--
-- Name: idx_attendees_product_id_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_product_id_deleted_at ON public.attendees USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_attendees_public_id_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_public_id_lower ON public.attendees USING btree (lower((public_id)::text));


--
-- Name: idx_attendees_public_id_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendees_public_id_trgm ON public.attendees USING gin (public_id public.gin_trgm_ops);


--
-- Name: idx_images_entity_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_images_entity_id ON public.images USING btree (entity_id);


--
-- Name: idx_images_entity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_images_entity_type ON public.images USING btree (entity_type);


--
-- Name: idx_images_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_images_type ON public.images USING btree (type);


--
-- Name: idx_offer_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_offer_expires_at ON public.waitlist_entries USING btree (offer_expires_at);


--
-- Name: idx_orders_email_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_email_trgm ON public.orders USING gin (email public.gin_trgm_ops);


--
-- Name: idx_orders_first_name_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_first_name_trgm ON public.orders USING gin (first_name public.gin_trgm_ops);


--
-- Name: idx_orders_last_name_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_last_name_trgm ON public.orders USING gin (last_name public.gin_trgm_ops);


--
-- Name: idx_orders_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_payment_status ON public.orders USING btree (payment_status);


--
-- Name: idx_orders_public_id_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_public_id_trgm ON public.orders USING gin (public_id public.gin_trgm_ops);


--
-- Name: idx_orders_refund_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_refund_status ON public.orders USING btree (refund_status);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_product_check_in_lists_product_id_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_check_in_lists_product_id_deleted_at ON public.product_check_in_lists USING btree (product_id, check_in_list_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_product_price_status_position; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_price_status_position ON public.waitlist_entries USING btree (product_price_id, status, "position");


--
-- Name: idx_product_prices_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_prices_product_id ON public.product_prices USING btree (product_id);


--
-- Name: idx_product_questions_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_product_questions_active ON public.product_questions USING btree (product_id, question_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_ticket_prices_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_prices_dates ON public.product_prices USING btree (sale_start_date, sale_end_date);


--
-- Name: idx_unique_email_product_price_occ_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_unique_email_product_price_occ_status ON public.waitlist_entries USING btree (email, product_price_id, COALESCE(event_occurrence_id, (0)::bigint), status) WHERE ((status)::text = ANY ((ARRAY['WAITING'::character varying, 'OFFERED'::character varying])::text[]));


--
-- Name: idx_waitlist_price_occ_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_waitlist_price_occ_status ON public.waitlist_entries USING btree (product_price_id, event_occurrence_id, status);


--
-- Name: locations_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locations_account_id_index ON public.locations USING btree (account_id);


--
-- Name: locations_organizer_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locations_organizer_id_index ON public.locations USING btree (organizer_id);


--
-- Name: locations_provider_place_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX locations_provider_place_unique ON public.locations USING btree (organizer_id, provider, provider_place_id) WHERE ((provider_place_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: messages_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_event_occurrence_id_index ON public.messages USING btree (event_occurrence_id);


--
-- Name: order_audit_logs_attendee_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_audit_logs_attendee_id_index ON public.order_audit_logs USING btree (attendee_id);


--
-- Name: order_audit_logs_event_id_created_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_audit_logs_event_id_created_at_index ON public.order_audit_logs USING btree (event_id, created_at);


--
-- Name: order_audit_logs_order_id_created_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_audit_logs_order_id_created_at_index ON public.order_audit_logs USING btree (order_id, created_at);


--
-- Name: order_items_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_items_event_occurrence_id_index ON public.order_items USING btree (event_occurrence_id);


--
-- Name: order_items_order_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_items_order_id_index ON public.order_items USING btree (order_id);


--
-- Name: order_items_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_items_product_id_index ON public.order_items USING btree (product_id);


--
-- Name: order_items_product_price_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_items_product_price_id_index ON public.order_items USING btree (product_price_id);


--
-- Name: order_payment_platform_fees_charge_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_payment_platform_fees_charge_id_index ON public.order_payment_platform_fees USING btree (charge_id);


--
-- Name: order_refunds_order_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_refunds_order_id_index ON public.order_refunds USING btree (order_id);


--
-- Name: order_refunds_refund_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_refunds_refund_id_index ON public.order_refunds USING btree (refund_id);


--
-- Name: orders_affiliate_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_affiliate_id_index ON public.orders USING btree (affiliate_id);


--
-- Name: orders_event_id_status_reserved_until_deleted_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_event_id_status_reserved_until_deleted_at_index ON public.orders USING btree (event_id, status, reserved_until, deleted_at);


--
-- Name: orders_promo_code_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_promo_code_id_index ON public.orders USING btree (promo_code_id);


--
-- Name: orders_short_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_short_id_index ON public.orders USING btree (short_id);


--
-- Name: orders_statistics_decremented_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_statistics_decremented_at_index ON public.orders USING btree (statistics_decremented_at);


--
-- Name: organizer_configurations_legacy_account_configuration_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_configurations_legacy_account_configuration_id_index ON public.organizer_configurations USING btree (legacy_account_configuration_id);


--
-- Name: organizer_stripe_platforms_organizer_id_stripe_connect_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_stripe_platforms_organizer_id_stripe_connect_platform ON public.organizer_stripe_platforms USING btree (organizer_id, stripe_connect_platform);


--
-- Name: organizer_stripe_platforms_stripe_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_stripe_platforms_stripe_account_id_index ON public.organizer_stripe_platforms USING btree (stripe_account_id);


--
-- Name: organizer_stripe_platforms_stripe_connect_platform_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_stripe_platforms_stripe_connect_platform_index ON public.organizer_stripe_platforms USING btree (stripe_connect_platform);


--
-- Name: organizer_vat_settings_vat_number_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_vat_settings_vat_number_index ON public.organizer_vat_settings USING btree (vat_number);


--
-- Name: organizer_vat_settings_vat_validated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_vat_settings_vat_validated_index ON public.organizer_vat_settings USING btree (vat_validated);


--
-- Name: organizer_vat_settings_vat_validation_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizer_vat_settings_vat_validation_status_index ON public.organizer_vat_settings USING btree (vat_validation_status);


--
-- Name: organizers_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizers_account_id_index ON public.organizers USING btree (account_id);


--
-- Name: organizers_location_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizers_location_id_index ON public.organizers USING btree (location_id);


--
-- Name: organizers_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizers_status_index ON public.organizers USING btree (status);


--
-- Name: outgoing_messages_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX outgoing_messages_event_id_index ON public.outgoing_messages USING btree (event_id);


--
-- Name: outgoing_messages_message_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX outgoing_messages_message_id_index ON public.outgoing_messages USING btree (message_id);


--
-- Name: password_reset_tokens_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_reset_tokens_email_index ON public.password_reset_tokens USING btree (email);


--
-- Name: password_reset_tokens_token_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_reset_tokens_token_index ON public.password_reset_tokens USING btree (token);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: product_addons_addon_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_addons_addon_product_id_index ON public.product_addons USING btree (addon_product_id);


--
-- Name: product_capacity_assignments_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_capacity_assignments_product_id_index ON public.product_capacity_assignments USING btree (product_id);


--
-- Name: product_categories_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_categories_event_id_index ON public.product_categories USING btree (event_id);


--
-- Name: product_categories_is_hidden_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_categories_is_hidden_index ON public.product_categories USING btree (is_hidden);


--
-- Name: product_categories_order_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_categories_order_index ON public.product_categories USING btree ("order");


--
-- Name: product_check_in_lists_check_in_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_check_in_lists_check_in_list_id_index ON public.product_check_in_lists USING btree (check_in_list_id);


--
-- Name: product_check_in_lists_product_id_check_in_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_check_in_lists_product_id_check_in_list_id_index ON public.product_check_in_lists USING btree (product_id, check_in_list_id);


--
-- Name: product_occurrence_visibility_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_occurrence_visibility_event_occurrence_id_index ON public.product_occurrence_visibility USING btree (event_occurrence_id);


--
-- Name: product_price_occurrence_overrides_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_price_occurrence_overrides_event_occurrence_id_index ON public.product_price_occurrence_overrides USING btree (event_occurrence_id);


--
-- Name: product_tax_and_fees_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_tax_and_fees_product_id_index ON public.product_taxes_and_fees USING btree (product_id);


--
-- Name: promo_codes_applicable_ticket_ids_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX promo_codes_applicable_ticket_ids_index ON public.promo_codes USING btree (applicable_product_ids);


--
-- Name: promo_codes_code_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX promo_codes_code_index ON public.promo_codes USING btree (code);


--
-- Name: promo_codes_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX promo_codes_event_id_index ON public.promo_codes USING btree (event_id);


--
-- Name: question_answers_attendee_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX question_answers_attendee_id_index ON public.question_answers USING btree (attendee_id);


--
-- Name: question_answers_order_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX question_answers_order_id_index ON public.question_answers USING btree (order_id);


--
-- Name: question_answers_question_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX question_answers_question_id_index ON public.question_answers USING btree (question_id);


--
-- Name: stripe_payments_stripe_platform_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stripe_payments_stripe_platform_index ON public.stripe_payments USING btree (stripe_platform);


--
-- Name: tax_and_fees_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tax_and_fees_account_id_index ON public.taxes_and_fees USING btree (account_id);


--
-- Name: ticket_capacity_assignments_capacity_assignment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ticket_capacity_assignments_capacity_assignment_id_index ON public.product_capacity_assignments USING btree (capacity_assignment_id);


--
-- Name: ticket_lookup_tokens_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ticket_lookup_tokens_email_index ON public.ticket_lookup_tokens USING btree (email);


--
-- Name: ticket_tax_and_fees_tax_and_fee_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ticket_tax_and_fees_tax_and_fee_id_index ON public.product_taxes_and_fees USING btree (tax_and_fee_id);


--
-- Name: waitlist_entries_email_product_price_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_email_product_price_id_index ON public.waitlist_entries USING btree (email, product_price_id);


--
-- Name: waitlist_entries_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_event_id_index ON public.waitlist_entries USING btree (event_id);


--
-- Name: waitlist_entries_event_id_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_event_id_status_index ON public.waitlist_entries USING btree (event_id, status);


--
-- Name: waitlist_entries_event_occurrence_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_event_occurrence_id_index ON public.waitlist_entries USING btree (event_occurrence_id);


--
-- Name: waitlist_entries_product_price_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_product_price_id_index ON public.waitlist_entries USING btree (product_price_id);


--
-- Name: waitlist_entries_product_price_id_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_product_price_id_status_index ON public.waitlist_entries USING btree (product_price_id, status);


--
-- Name: waitlist_entries_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waitlist_entries_status_index ON public.waitlist_entries USING btree (status);


--
-- Name: webhook_logs_event_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhook_logs_event_type_index ON public.webhook_logs USING btree (event_type);


--
-- Name: webhook_logs_webhook_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhook_logs_webhook_id_index ON public.webhook_logs USING btree (webhook_id);


--
-- Name: webhooks_account_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhooks_account_id_index ON public.webhooks USING btree (account_id);


--
-- Name: webhooks_event_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhooks_event_id_index ON public.webhooks USING btree (event_id);


--
-- Name: webhooks_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhooks_status_index ON public.webhooks USING btree (status);


--
-- Name: account_attributions account_attributions_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_attributions
    ADD CONSTRAINT account_attributions_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_stripe_platforms account_stripe_platforms_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stripe_platforms
    ADD CONSTRAINT account_stripe_platforms_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_users account_users_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_users
    ADD CONSTRAINT account_users_users_id_fk FOREIGN KEY (invited_by_user_id) REFERENCES public.users(id);


--
-- Name: account_vat_settings account_vat_settings_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_vat_settings
    ADD CONSTRAINT account_vat_settings_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: accounts accounts_account_configuration_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_configuration_id_foreign FOREIGN KEY (account_configuration_id) REFERENCES public.account_configuration(id) ON DELETE SET NULL;


--
-- Name: accounts accounts_account_messaging_tier_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_messaging_tier_id_foreign FOREIGN KEY (account_messaging_tier_id) REFERENCES public.account_messaging_tiers(id) ON DELETE SET NULL;


--
-- Name: affiliates affiliates_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affiliates
    ADD CONSTRAINT affiliates_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: affiliates affiliates_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affiliates
    ADD CONSTRAINT affiliates_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: announcement_users announcement_users_announcement_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_users
    ADD CONSTRAINT announcement_users_announcement_id_foreign FOREIGN KEY (announcement_id) REFERENCES public.announcements(id) ON DELETE CASCADE;


--
-- Name: announcement_users announcement_users_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_users
    ADD CONSTRAINT announcement_users_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendee_check_ins attendee_check_ins_attendee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_attendee_id_foreign FOREIGN KEY (attendee_id) REFERENCES public.attendees(id) ON DELETE CASCADE;


--
-- Name: attendee_check_ins attendee_check_ins_check_in_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_check_in_list_id_foreign FOREIGN KEY (check_in_list_id) REFERENCES public.check_in_lists(id) ON DELETE CASCADE;


--
-- Name: attendee_check_ins attendee_check_ins_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: attendee_check_ins attendee_check_ins_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE SET NULL;


--
-- Name: attendee_check_ins attendee_check_ins_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: attendee_check_ins attendee_check_ins_ticket_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendee_check_ins
    ADD CONSTRAINT attendee_check_ins_ticket_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: attendees attendees_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE SET NULL;


--
-- Name: attendees attendees_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: attendees attendees_ticket_prices_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_ticket_prices_id_fk FOREIGN KEY (product_price_id) REFERENCES public.product_prices(id);


--
-- Name: attendees attendees_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_users_id_fk FOREIGN KEY (checked_out_by) REFERENCES public.users(id);


--
-- Name: capacity_assignments capacity_assignments_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.capacity_assignments
    ADD CONSTRAINT capacity_assignments_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: check_in_lists check_in_lists_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_in_lists
    ADD CONSTRAINT check_in_lists_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: check_in_lists check_in_lists_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_in_lists
    ADD CONSTRAINT check_in_lists_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE SET NULL;


--
-- Name: email_templates email_templates_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: email_templates email_templates_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: email_templates email_templates_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.organizers(id) ON DELETE CASCADE;


--
-- Name: event_daily_statistics event_daily_statistics_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_daily_statistics
    ADD CONSTRAINT event_daily_statistics_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_locations event_locations_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_locations
    ADD CONSTRAINT event_locations_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_locations event_locations_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_locations
    ADD CONSTRAINT event_locations_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: event_logs event_logs_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_logs
    ADD CONSTRAINT event_logs_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: event_occurrence_daily_statistics event_occurrence_daily_statistics_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_daily_statistics
    ADD CONSTRAINT event_occurrence_daily_statistics_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_occurrence_daily_statistics event_occurrence_daily_statistics_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_daily_statistics
    ADD CONSTRAINT event_occurrence_daily_statistics_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id);


--
-- Name: event_occurrence_statistics event_occurrence_statistics_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_statistics
    ADD CONSTRAINT event_occurrence_statistics_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_occurrence_statistics event_occurrence_statistics_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrence_statistics
    ADD CONSTRAINT event_occurrence_statistics_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id);


--
-- Name: event_occurrences event_occurrences_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrences
    ADD CONSTRAINT event_occurrences_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_occurrences event_occurrences_event_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_occurrences
    ADD CONSTRAINT event_occurrences_event_location_id_foreign FOREIGN KEY (event_location_id) REFERENCES public.event_locations(id) ON DELETE SET NULL;


--
-- Name: event_settings event_settings_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_settings
    ADD CONSTRAINT event_settings_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_statistics event_statistics_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_statistics
    ADD CONSTRAINT event_statistics_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: events events_event_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_event_location_id_foreign FOREIGN KEY (event_location_id) REFERENCES public.event_locations(id) ON DELETE SET NULL;


--
-- Name: events events_organizers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_organizers_id_fk FOREIGN KEY (organizer_id) REFERENCES public.organizers(id);


--
-- Name: account_users fk_account_users_accounts; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_users
    ADD CONSTRAINT fk_account_users_accounts FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_users fk_account_users_users; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_users
    ADD CONSTRAINT fk_account_users_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: question_answers fk_attendeed_attendee_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_answers
    ADD CONSTRAINT fk_attendeed_attendee_id FOREIGN KEY (attendee_id) REFERENCES public.attendees(id);


--
-- Name: attendees fk_attendees_checked_in_by_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT fk_attendees_checked_in_by_id FOREIGN KEY (checked_in_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendees fk_attendees_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT fk_attendees_order_id FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: attendees fk_attendees_ticket_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT fk_attendees_ticket_id FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: events fk_events_account_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_account_id FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: events fk_events_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: order_items fk_order_items_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_order_id FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items fk_order_items_ticket_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_ticket_id FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders fk_orders_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders_event_id FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: question_answers fk_orders_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_answers
    ADD CONSTRAINT fk_orders_order_id FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: question_answers fk_question_answers_question_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_answers
    ADD CONSTRAINT fk_question_answers_question_id FOREIGN KEY (question_id) REFERENCES public.questions(id);


--
-- Name: product_prices fk_ticket_prices_ticket_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_prices
    ADD CONSTRAINT fk_ticket_prices_ticket_id FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_questions fk_ticket_questions_question_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_questions
    ADD CONSTRAINT fk_ticket_questions_question_id FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: product_questions fk_ticket_questions_ticket_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_questions
    ADD CONSTRAINT fk_ticket_questions_ticket_id FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products fk_tickets_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_tickets_event_id FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: question_answers fk_tickets_ticket_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_answers
    ADD CONSTRAINT fk_tickets_ticket_id FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: images images_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: locations locations_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: locations locations_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.organizers(id) ON DELETE CASCADE;


--
-- Name: messages messages_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE SET NULL;


--
-- Name: messages messages_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: messages messages_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_users_id_fk FOREIGN KEY (sent_by_user_id) REFERENCES public.users(id);


--
-- Name: order_application_fees order_application_fees_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_application_fees
    ADD CONSTRAINT order_application_fees_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_audit_logs order_audit_logs_attendee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_audit_logs
    ADD CONSTRAINT order_audit_logs_attendee_id_foreign FOREIGN KEY (attendee_id) REFERENCES public.attendees(id) ON DELETE SET NULL;


--
-- Name: order_audit_logs order_audit_logs_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_audit_logs
    ADD CONSTRAINT order_audit_logs_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: order_audit_logs order_audit_logs_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_audit_logs
    ADD CONSTRAINT order_audit_logs_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE SET NULL;


--
-- Name: order_items order_items_ticket_prices_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_ticket_prices_id_fk FOREIGN KEY (product_price_id) REFERENCES public.product_prices(id);


--
-- Name: order_payment_platform_fees order_payment_platform_fees_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_payment_platform_fees
    ADD CONSTRAINT order_payment_platform_fees_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_refunds order_refunds_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_refunds
    ADD CONSTRAINT order_refunds_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_affiliate_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_affiliate_id_foreign FOREIGN KEY (affiliate_id) REFERENCES public.affiliates(id) ON DELETE SET NULL;


--
-- Name: orders orders_promo_codes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_promo_codes_id_fk FOREIGN KEY (promo_code_id) REFERENCES public.promo_codes(id);


--
-- Name: organizer_settings organizer_settings_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_settings
    ADD CONSTRAINT organizer_settings_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.organizers(id) ON DELETE CASCADE;


--
-- Name: organizer_stripe_platforms organizer_stripe_platforms_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_stripe_platforms
    ADD CONSTRAINT organizer_stripe_platforms_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.organizers(id) ON DELETE CASCADE;


--
-- Name: organizer_vat_settings organizer_vat_settings_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizer_vat_settings
    ADD CONSTRAINT organizer_vat_settings_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.organizers(id) ON DELETE CASCADE;


--
-- Name: organizers organizers_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizers
    ADD CONSTRAINT organizers_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: organizers organizers_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizers
    ADD CONSTRAINT organizers_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: organizers organizers_organizer_configuration_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizers
    ADD CONSTRAINT organizers_organizer_configuration_id_foreign FOREIGN KEY (organizer_configuration_id) REFERENCES public.organizer_configurations(id) ON DELETE SET NULL;


--
-- Name: outgoing_messages outgoing_messages_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.outgoing_messages
    ADD CONSTRAINT outgoing_messages_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: outgoing_messages outgoing_messages_message_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.outgoing_messages
    ADD CONSTRAINT outgoing_messages_message_id_foreign FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: product_addons product_addons_addon_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_addons
    ADD CONSTRAINT product_addons_addon_product_id_foreign FOREIGN KEY (addon_product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_addons product_addons_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_addons
    ADD CONSTRAINT product_addons_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_categories product_categories_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: product_occurrence_visibility product_occurrence_visibility_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_occurrence_visibility
    ADD CONSTRAINT product_occurrence_visibility_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE CASCADE;


--
-- Name: product_occurrence_visibility product_occurrence_visibility_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_occurrence_visibility
    ADD CONSTRAINT product_occurrence_visibility_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_price_occurrence_overrides product_price_occurrence_overrides_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_price_occurrence_overrides
    ADD CONSTRAINT product_price_occurrence_overrides_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE CASCADE;


--
-- Name: product_price_occurrence_overrides product_price_occurrence_overrides_product_price_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_price_occurrence_overrides
    ADD CONSTRAINT product_price_occurrence_overrides_product_price_id_foreign FOREIGN KEY (product_price_id) REFERENCES public.product_prices(id) ON DELETE CASCADE;


--
-- Name: products products_product_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_category_id_foreign FOREIGN KEY (product_category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: promo_codes promo_codes_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: questions questions_event_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_event_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: roles roles_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: stripe_payments stripe_payments_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stripe_payments
    ADD CONSTRAINT stripe_payments_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: product_capacity_assignments ticket_capacity_assignments_capacity_assignment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_capacity_assignments
    ADD CONSTRAINT ticket_capacity_assignments_capacity_assignment_id_foreign FOREIGN KEY (capacity_assignment_id) REFERENCES public.capacity_assignments(id) ON DELETE CASCADE;


--
-- Name: product_capacity_assignments ticket_capacity_assignments_ticket_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_capacity_assignments
    ADD CONSTRAINT ticket_capacity_assignments_ticket_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_check_in_lists ticket_check_in_lists_check_in_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_check_in_lists
    ADD CONSTRAINT ticket_check_in_lists_check_in_list_id_foreign FOREIGN KEY (check_in_list_id) REFERENCES public.check_in_lists(id) ON DELETE CASCADE;


--
-- Name: product_check_in_lists ticket_check_in_lists_ticket_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_check_in_lists
    ADD CONSTRAINT ticket_check_in_lists_ticket_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_taxes_and_fees ticket_tax_and_fees_tax_and_fees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_taxes_and_fees
    ADD CONSTRAINT ticket_tax_and_fees_tax_and_fees_id_fk FOREIGN KEY (tax_and_fee_id) REFERENCES public.taxes_and_fees(id) ON DELETE CASCADE;


--
-- Name: product_taxes_and_fees ticket_tax_and_fees_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_taxes_and_fees
    ADD CONSTRAINT ticket_tax_and_fees_tickets_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: waitlist_entries waitlist_entries_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: waitlist_entries waitlist_entries_event_occurrence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_event_occurrence_id_foreign FOREIGN KEY (event_occurrence_id) REFERENCES public.event_occurrences(id) ON DELETE SET NULL;


--
-- Name: waitlist_entries waitlist_entries_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: waitlist_entries waitlist_entries_product_price_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_product_price_id_foreign FOREIGN KEY (product_price_id) REFERENCES public.product_prices(id) ON DELETE CASCADE;


--
-- Name: webhook_logs webhook_logs_webhook_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_webhook_id_foreign FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.organizers(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fUBnUJj7LfD5R0RB6YvkV8J2bUc3Wrey1RB6CQ5Ee8ivBN7aWeHCax0Tn9PXfvE

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict vSr5zHqytUs2EUqGg9lJax2hSRcPQlFnuYC7nVw3aOR6JZMn2paYb7IZ1Ipast1

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict vSr5zHqytUs2EUqGg9lJax2hSRcPQlFnuYC7nVw3aOR6JZMn2paYb7IZ1Ipast1

--
-- PostgreSQL database cluster dump complete
--

